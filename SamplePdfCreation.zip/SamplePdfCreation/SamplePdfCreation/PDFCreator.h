//
//  PDFCreator.h
//  TravelRequest
//
//  Created by VMF2 on 10/9/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Constant.h"
//static NSInteger nPrePage = 1;
static BOOL bItem = NO;


@protocol PDFDelegate;


@interface PDFCreator : NSObject
{
    id<PDFDelegate> pdfDelegate;
    BOOL bShowQtyRate;
    BOOL bShowCode;
    BOOL bShowTax;
    BOOL bShowDiscount;
    
    NSInteger nCurrentPage;
}

@property (nonatomic, strong) id<PDFDelegate> pdfDelegate;

@property (nonatomic, assign) double dblCodeWidth;
@property (nonatomic, assign) double dblDescWidth;
@property (nonatomic, assign) double dblQtyWidth;
@property (nonatomic, assign) double dblRateWidth;
@property (nonatomic, assign) double dblDiscountWidth;
@property (nonatomic, assign) double dblTaxWidth;
@property (nonatomic, assign) double dblAmountWidth;
@property (nonatomic, assign) NSInteger nCurrentPage;

@property (nonatomic, strong) NSMutableDictionary *invoiceDict;

- (void)deleteAllPdf;
- (void)CreatePDFFile:(NSMutableDictionary *)documentDict;
- (void) drawBorder:(CGRect)pageRect pdfContext:(CGContextRef) pdfContext;
- (void) drawText:(NSString *)textToDraw pageRect:(CGRect)pageRect pdfContext:(CGContextRef) pdfContext;
- (CGFloat)getyPosition:(CGRect)pageRect yPosition:(CGFloat)fy context:(CGContextRef )currentContext DocumentDict:(NSMutableDictionary *)documentDict;

@end

@protocol PDFDelegate <NSObject>

@required
- (void)pdfCreatedSuccessfully:(NSString *)sFileName;
- (void)pdfCreationFailed:(NSString *)sFileName;

@end


