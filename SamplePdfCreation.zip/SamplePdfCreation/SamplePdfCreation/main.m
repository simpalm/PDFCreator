//
//  main.m
//  SamplePdfCreation
//
//  Created by VMFactor on 4/17/13.
//  Copyright (c) 2013 simpalm. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "googleMapLocatorAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([googleMapLocatorAppDelegate class]));
    }
}
