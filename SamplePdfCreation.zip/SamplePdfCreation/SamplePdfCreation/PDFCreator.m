//
//  PDFCreator.m
//  TravelRequest
//
//  Created by VMF2 on 10/9/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "PDFCreator.h"


@implementation PDFCreator


@synthesize pdfDelegate;

@synthesize dblCodeWidth;
@synthesize dblDescWidth;
@synthesize dblQtyWidth;
@synthesize dblRateWidth;
@synthesize dblDiscountWidth;
@synthesize dblTaxWidth;
@synthesize dblAmountWidth;
@synthesize nCurrentPage;
@synthesize invoiceDict;


- (void)deleteAllPdf
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *arr = [fileManager contentsOfDirectoryAtPath:kDocumentsDirectory error:nil];
    for(int i=0; i<[arr count] ;i++)
    {
        NSString *fileName = [arr objectAtIndex:i];
        NSString *pdfFileName = [kDocumentsDirectory stringByAppendingPathComponent:fileName];
        
        [fileManager removeItemAtPath:pdfFileName error:nil];
    }
}

- (void) drawBorder:(CGRect)pageRect pdfContext:(CGContextRef) pdfContext
{
    //CGContextRef    currentContext = UIGraphicsGetCurrentContext();
    UIColor *borderColor = [UIColor brownColor];
    
    CGRect rectFrame = CGRectMake(kBorderInset, kBorderInset, pageRect.size.width-kBorderInset*2, pageRect.size.height-kBorderInset*2);
    
    CGContextSetStrokeColorWithColor(pdfContext, borderColor.CGColor);
    CGContextSetLineWidth(pdfContext, kBorderWidth);
    CGContextStrokeRect(pdfContext, rectFrame);
}

- (CGPathRef) newPathForRoundedRect:(CGRect)rect radius:(CGFloat)radius
{
	CGMutablePathRef retPath = CGPathCreateMutable();
    
	CGRect innerRect = CGRectInset(rect, radius, radius);
    
	CGFloat inside_right = innerRect.origin.x + innerRect.size.width;
	CGFloat outside_right = rect.origin.x + rect.size.width;
	CGFloat inside_bottom = innerRect.origin.y + innerRect.size.height;
	CGFloat outside_bottom = rect.origin.y + rect.size.height;
    
	CGFloat inside_top = innerRect.origin.y;
	CGFloat outside_top = rect.origin.y;
	CGFloat outside_left = rect.origin.x;
    
	CGPathMoveToPoint(retPath, NULL, innerRect.origin.x, outside_top);
    
	CGPathAddLineToPoint(retPath, NULL, inside_right, outside_top);
	CGPathAddArcToPoint(retPath, NULL, outside_right, outside_top, outside_right, inside_top, radius);
	CGPathAddLineToPoint(retPath, NULL, outside_right, inside_bottom);
	CGPathAddArcToPoint(retPath, NULL,  outside_right, outside_bottom, inside_right, outside_bottom, radius);
    
	CGPathAddLineToPoint(retPath, NULL, innerRect.origin.x, outside_bottom);
	CGPathAddArcToPoint(retPath, NULL,  outside_left, outside_bottom, outside_left, inside_bottom, radius);
	CGPathAddLineToPoint(retPath, NULL, outside_left, inside_top);
	CGPathAddArcToPoint(retPath, NULL,  outside_left, outside_top, innerRect.origin.x, outside_top, radius);
    
	CGPathCloseSubpath(retPath);
    
	return retPath;
}

- (void) drawRect:(CGRect)rect pdfContext:(CGContextRef) pdfContext
{
	//CGContextRef ctx = UIGraphicsGetCurrentContext();
    
	//CGRect frame = self.bounds;
    
	CGPathRef roundedRectPath = [self newPathForRoundedRect:rect radius:5];
    
	[[UIColor darkGrayColor] set];
    
	CGContextAddPath(pdfContext, roundedRectPath);
    CGContextStrokePath(pdfContext);
	CGPathRelease(roundedRectPath);
}

- (void) drawText:(NSString *)textToDraw pageRect:(CGRect)pageRect pdfContext:(CGContextRef) pdfContext
{
    CGContextSetRGBFillColor(pdfContext, 0.0, 0.0, 0.0, 1.0);
    
    UIFont *font = [UIFont systemFontOfSize:14.0];
    
    CGSize stringSize = [textToDraw sizeWithFont:font
                               constrainedToSize:CGSizeMake(pageRect.size.width - 2*kBorderInset-2*kMarginInset, pageRect.size.height - 2*kBorderInset - 2*kMarginInset)
                                   lineBreakMode:UILineBreakModeWordWrap];
    
    CGRect renderingRect = CGRectMake(kBorderInset + kMarginInset, kBorderInset + kMarginInset + 50.0, pageRect.size.width - 2*kBorderInset - 2*kMarginInset, stringSize.height);
    
    [textToDraw drawInRect:renderingRect 
                  withFont:font
             lineBreakMode:UILineBreakModeWordWrap
                 alignment:UITextAlignmentLeft];
    
}


- (CGFloat )getyPosition:(CGRect)pageRect yPosition:(CGFloat)fy context:(CGContextRef )currentContext DocumentDict:(NSMutableDictionary *)documentDict;
{
    if(fy >= (pageRect.size.height-[self getFooterHeight:pageRect DocumentDict:documentDict]))
    {
        [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fy showFooter:NO];
        UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, pageRect.size.width, pageRect.size.height), nil);
        nCurrentPage ++;
        
        AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        NSString *sTemplateID = [appDelegate.settingsDict valueForKey:kDbKeyValue_templateID];
        if([sTemplateID isEqualToString:@"0"])
         {
             fy = 80;
             fy= [self createHeader:pageRect context:currentContext DocumentDict:documentDict X:50.0 Y:fy];
         }
         else if([sTemplateID isEqualToString:@"1"])
         {
             fy = kPDF_MARGIN;
             fy= [self createHeaderForTemplate2:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN+5 Y:fy];
         }
         else if([sTemplateID isEqualToString:@"2"])
         {
             fy = 50;
             fy= [self createHeaderForTemplate3:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN+5 Y:fy];

         }
        else if([sTemplateID isEqualToString:@"3"])
        {
            fy = kPDF_MARGIN;
            fy= [self createHeaderForTemplate4:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN+5 Y:fy];
        }
        else if([sTemplateID isEqualToString:@"4"])
        {
            fy = kPDF_MARGIN;
            fy= [self createHeaderForTemplate5:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN+5 Y:fy];
        }

        
        fy+=20;
        
        if(bItem)
        {
            if([sTemplateID isEqualToString:@"0"])
            {
                fy = [self createItemHeader:pageRect context:currentContext fy:fy fx:kPDF_MARGIN showLine:NO showRect:YES]+10;
            }
            else if([sTemplateID isEqualToString:@"1"])
            {
                fy = [self createItemHeader:pageRect context:currentContext fy:fy fx:kPDF_MARGIN showLine:YES showRect:YES]+2;
            }
            else if([sTemplateID isEqualToString:@"2"])
            {
                fy = [self createItemHeader:pageRect context:currentContext fy:fy fx:kPDF_MARGIN showLine:NO showRect:NO]+10;
                
            }
            else if([sTemplateID isEqualToString:@"3"])
            {
                fy = [self createItemHeader:pageRect context:currentContext fy:fy fx:kPDF_MARGIN showLine:YES showRect:NO]+2;
                
            }
            else if([sTemplateID isEqualToString:@"4"])
            {
                fy = [self createItemHeader:pageRect context:currentContext fy:fy fx:kPDF_MARGIN showLine:YES showRect:YES]+2;
                
            }
            //bItem = NO;
        }
    }
    return fy;
}


- (CGFloat) createCompanyHeader:(CGRect)pageRect context:(CGContextRef)currentContext DocumentDict:(NSMutableDictionary *)documentDict X:(CGFloat)fX Y:(CGFloat)fY
{
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    CGSize maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 50), 200);
    CGSize expectedLabelSize;
    CGFloat x = fX;
    
    NSString *sTemplateID = [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID];

    
    NSString *skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyName];//[self getKeyValueForID:@"companyName" Disc:keyDisc];
    // ___________________________________________________________________________
    
    CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kCOMPANY_NAME_FONT_NUMBER, kCGEncodingMacRoman);
    
    if([sTemplateID isEqualToString:@"3"])
    {
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR_TEMP4, kTEXT_GREEN_COLOR_TEMP4, kTEXT_BLUE_COLOR_TEMP4, 1.0);
    }
    else if([sTemplateID isEqualToString:@"4"])
    {
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    }
    else
    {
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    }
    
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_NAME_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    
    
    //CGContextShowTextAtPoint (currentContext, 100, 1000, text, strlen(text));
    [skey drawInRect:CGRectMake(x, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_NAME_FONT];
    
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress1];//[self getKeyValueForID:@"companyAddress1" Disc:keyDisc];
    
    fY += expectedLabelSize.height;
    
    CGContextSelectFont (currentContext, kFONT_NAME, kCOMPANY_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
    if(([sTemplateID isEqualToString:@"3"]) || ([sTemplateID isEqualToString:@"4"]))
    {
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_GREEN_COLOR, 1.0);
    }
    else
    {
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    }

    
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_ADDR_FONT];
    
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress2];//[self getKeyValueForID:@"companyAddress2" Disc:keyDisc];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_ADDR_FONT];
    
    
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress3];//[self getKeyValueForID:@"companyAddress3" Disc:keyDisc];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_ADDR_FONT];
    
   // AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];

  //  NSString *sTemplateID = [appDelegate.settingsDict valueForKey:kDbKeyValue_templateID];
   // if([sTemplateID isEqualToString:@"0"])
    {
        CGContextSelectFont (currentContext, kFONT_NAME, kCOMPANY_CONTACT_FONT_NUMBER, kCGEncodingMacRoman);

        skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact1];//[self getKeyValueForID:@"companyContact1" Disc:keyDisc];
        fY += (expectedLabelSize.height + 10);
        expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_CONTACT_FONT];
        
        skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact2];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
        fY += expectedLabelSize.height;
        expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_CONTACT_FONT];
        
        skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact3];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
        fY += expectedLabelSize.height;
        expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_CONTACT_FONT];
        
        skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact4];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
        fY += expectedLabelSize.height;
        expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_CONTACT_FONT];
        
        skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact5];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
        fY += expectedLabelSize.height;
        expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_CONTACT_FONT];
    }
    return fY;
}

- (CGFloat)getFooterHeight:(CGRect)pageRect DocumentDict:(NSMutableDictionary *)documentDict
{
    CGFloat height = 5;

    CGSize maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 50), 200);
    CGSize expectedLabelSize;
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    

    CGFloat y = height;
    
    maximumLabelSize.width = (pageRect.size.width-kPDF_MARGIN*2)/2+100 ;
    NSString *skey = [NSString stringWithFormat:@"REMITTANCE ADVICE FOR invoice #%@ on %@", [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_DocumentNumber], [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_DocumentDate]];
        
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height += expectedLabelSize.height;
    

    skey = [NSString stringWithFormat:@"Received From:          %@", [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ClientName]];
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    skey = [NSString stringWithFormat:@"Balance Due:          %@", [[invoiceDict valueForKey:kInvoice_CALCULATIONINFO] valueForKey:kInvoice_BalanceDue]]; ////CHECK
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    skey = [NSString stringWithFormat:@"Amount Paid:          %@", [[invoiceDict valueForKey:kInvoice_CALCULATIONINFO] valueForKey:kDbInvoice_PartPayment]];////CHECK
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height += expectedLabelSize.height;
    
    
    maximumLabelSize.width = (pageRect.size.width-kPDF_MARGIN*2)/2-100 ;
    skey = [NSString stringWithFormat:@"Please detach and send with remittance to: %@", [appdelegate.settingsDict valueForKey:kDbKeyValue_companyName]];
    expectedLabelSize = [skey sizeWithFont:[UIFont systemFontOfSize:9] constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    y += expectedLabelSize.height;
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress1];//[self getKeyValueForID:@"companyAddress1" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    y += expectedLabelSize.height;
    
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress2];//[self getKeyValueForID:@"companyAddress2" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    y += expectedLabelSize.height;
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress3];//[self getKeyValueForID:@"companyAddress3" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    y+= expectedLabelSize.height;
    
    
    if(height > y)
    {
        return height+10;
    }
    else
        return y+10;
}


- (CGFloat)getCompanyHeaderHeight:(CGRect)pageRect DocumentDict:(NSMutableDictionary *)documentDict 

{
    CGFloat height = 5;
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];

    
    CGSize maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 50), 200);
    NSString *sStr = @"INVOICE";
    CGSize expectedLabelSize = [sStr sizeWithFont:kINVOICE_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height += expectedLabelSize.height;
    
    NSString *skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyName];//[self getKeyValueForID:@"companyName" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_NAME_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height += expectedLabelSize.height;
    
    return height;
}

- (CGFloat)getCompanyHeaderHeightForTemp3:(CGRect)pageRect DocumentDict:(NSMutableDictionary *)documentDict
{
    CGFloat height = 0;
    CGFloat y = 0;
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    CGSize maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 50), 200);

    NSString *skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress1];//[self getKeyValueForID:@"companyAddress1" Disc:keyDisc];
    CGSize expectedLabelSize = [skey sizeWithFont:kCOMPANY_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress2];//[self getKeyValueForID:@"companyAddress2" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress3];//[self getKeyValueForID:@"companyAddress3" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact1];//[self getKeyValueForID:@"companyContact1" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact2];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact3];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact4];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact5];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;

    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_DocumentNumber];//@"documentInfo.documentNumber"];
    skey = [NSString stringWithFormat:@"Invoice No:      %@", skey];
    
    maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 100), 200);
    expectedLabelSize = [skey sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    y+=expectedLabelSize.height;
    
    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_DocumentDate];//]@"documentInfo.documentDate"];//[self getKeyValueForID:@"documentDate" Disc:invoiceDict];
    skey = [NSString stringWithFormat:@"Date:               %@", skey];
    expectedLabelSize = [skey sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    y+= expectedLabelSize.height;
    
    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Terms];//@"documentInfo.terms"];//[self getKeyValueForID:@"terms" Disc:invoiceDict];
    skey = [NSString stringWithFormat:@"Terms:            %@", skey];
    expectedLabelSize = [skey sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    y+= expectedLabelSize.height;
    
    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kInvoice_DocumentDueDate];//@"documentInfo.documentDueDate"];//[dateFormatter stringFromDate:dueDate];
    skey = [NSString stringWithFormat:@"Due Date:       %@", skey];
    expectedLabelSize = [skey sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    y+= expectedLabelSize.height;
    
    if(height>y)
    {
        return height;
    }
    else
        return y;
}

- (CGFloat )getBillShipHeightForTemp3:(CGRect)pageRect DocumentDict:(NSMutableDictionary *)documentDict
{
    CGFloat height = 0;
    NSString *skey;
    CGSize maximumLabelSize;
    CGSize expectedLabelSize;
    CGFloat y= height;
    
    maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 120), 500);
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ClientName];//@"customerInfo.contactName"];
    expectedLabelSize = [skey sizeWithFont:kBILL_CUSTOMER_NAME_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine3];//[self getKeyValueForID:@"addressLine1" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine2];//[self getKeyValueForID:@"addressLine2" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height+= expectedLabelSize.height;
    
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine3];//[self getKeyValueForID:@"addressLine3" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    height += expectedLabelSize.height;
    
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine1];//[self getKeyValueForID:@"shippingAddressLine1" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kSHIP_CUSTOMER_ADDR1_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    y += expectedLabelSize.height;
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine2];//[self getKeyValueForID:@"shippingAddressLine2" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    y+= expectedLabelSize.height;
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine3];//[self getKeyValueForID:@"shippingAddressLine3" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    y+= expectedLabelSize.height;
    
    CGFloat fRectHeight;
    if(height > y)
        fRectHeight = height;
    else
        fRectHeight = y;
    
    return fRectHeight;

}

- (CGFloat) createHeaderForTemplate2:(CGRect)pageRect context:(CGContextRef)currentContext DocumentDict:(NSMutableDictionary *)documentDict X:(CGFloat)fX Y:(CGFloat)fY
{
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    CGContextSetTextDrawingMode (currentContext, kCGTextFill);
    
    NSString *sTemplateID = [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID];
    
    NSString *sPath = [NSString stringWithFormat:@"templateBg_%@.png", sTemplateID];
    UIImage *demoImage = [UIImage imageNamed:sPath];
    [demoImage drawInRect:CGRectMake(0, 05, pageRect.size.width, pageRect.size.height)];
    

    CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kINVOICE_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    CGContextSetTextDrawingMode (currentContext, kCGTextFill);
    
    CGSize maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 50), 200);
    NSString *sStr = @"Invoice";
    
    NSString *sType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];//@"documentInfo.type"];
    if([sType isEqualToString:@"inv"])
    {
        sStr = @"Invoice";
    }
    else if([sType isEqualToString:@"est"])
    {
        sStr = @"Estimate";
    }
    else if([sType isEqualToString:@"po"])
    {
        sStr = @"Purchase Order";
    }
    else if([sType isEqualToString:@"crn"])
    {
        sStr = @"Credit Memo";
    }

    
    CGSize expectedLabelSize = [sStr sizeWithFont:kINVOICE_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sStr drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kINVOICE_FONT];
    
    fY += expectedLabelSize.height;
    fY = [self createCompanyHeader:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
    return fY;
}


- (CGFloat) createHeader:(CGRect)pageRect context:(CGContextRef)currentContext DocumentDict:(NSMutableDictionary *)documentDict X:(CGFloat)fX Y:(CGFloat)fY
{
    CGFloat x = fX;
    CGFloat y;

    
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    CGContextSetTextDrawingMode (currentContext, kCGTextFill);
    
    NSString *sTemplateID = [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID];
    
    NSString *sPath = [NSString stringWithFormat:@"templateBg_%@.png", sTemplateID];
    UIImage *demoImage = [UIImage imageNamed:sPath];
    [demoImage drawInRect:CGRectMake(0, 05, pageRect.size.width, pageRect.size.height)];
    
    
    CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kINVOICE_FONT_NUMBER, kCGEncodingMacRoman);
    
    CGContextSetRGBFillColor(currentContext, (138.0/255.0), (237.0/255.0), (244.0/255.0), 1.0);
    CGContextSetTextDrawingMode (currentContext, kCGTextFill);
    
    CGSize maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 50), 200);
    NSString *sStr;
    NSString *sType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];//@"documentInfo.type"];
    if([sType isEqualToString:@"inv"])
    {
        sStr = @"INVOICE";
    }
    else if([sType isEqualToString:@"est"])
    {
        sStr = @"ESTIMATE";
    }
    else if([sType isEqualToString:@"po"])
    {
        sStr = @"PURCHASE ORDER";
    }
    else if([sType isEqualToString:@"crn"])
    {
        sStr = @"CREDIT MEMO";
    }
    
    CGSize expectedLabelSize = [sStr sizeWithFont:kINVOICE_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    
    
    fX = (pageRect.size.width - kPDF_MARGIN*2)/2+50;
    
        [sStr drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, maximumLabelSize.height) withFont:kINVOICE_FONT];
    
    fY += expectedLabelSize.height;
    y = fY;
    
    fY = [self createCompanyHeader:pageRect context:currentContext DocumentDict:documentDict X:x Y:fY];
    
    
    CGContextSelectFont (currentContext, kFONT_NAME, kDOCUMENT_INFO_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    NSString *skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_DocumentNumber];//@"documentInfo.documentNumber"];//[self getKeyValueForID:@"documentNumber" Disc:invoiceDict];
    NSString *sTextToDraw;

       x = fX;
    
    //fY = y;
    sTextToDraw = [NSString stringWithFormat:@"Invoice No:      %@", skey];
    maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 100), 200);
    expectedLabelSize = [sTextToDraw sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    
   
        [sTextToDraw drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];    
    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_DocumentDate];//@"documentInfo.documentDate"];//[self getKeyValueForID:@"documentDate" Disc:invoiceDict];
    y += (expectedLabelSize.height);
    sTextToDraw = [NSString stringWithFormat:@"Date:                %@", skey];
    expectedLabelSize = [sTextToDraw sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];

    
        [sTextToDraw drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    
    
    if(![sTemplateID isEqualToString:@"3"])
    {
        skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Terms];//@"documentInfo.terms"];//[self getKeyValueForID:@"terms" Disc:invoiceDict];
        y += (expectedLabelSize.height);
        sTextToDraw = [NSString stringWithFormat:@"Terms:              %@", skey];
        expectedLabelSize = [sTextToDraw sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [sTextToDraw drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
        
        skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kInvoice_DocumentDueDate];//@"documentInfo.documentDueDate"];//[dateFormatter stringFromDate:dueDate];
        y += (expectedLabelSize.height);
        sTextToDraw = [NSString stringWithFormat:@"Due Date:         %@", skey];
        expectedLabelSize = [sTextToDraw sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [sTextToDraw drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
        y+= expectedLabelSize.height;
    }
    
    if(fY>y)
    {
        return fY;
    }
    else
        return y;

}

- (CGFloat) createHeaderForTemplate3:(CGRect)pageRect context:(CGContextRef)currentContext DocumentDict:(NSMutableDictionary *)documentDict X:(CGFloat)fX Y:(CGFloat)fY
{
    CGFloat x = fX;
    CGFloat y;
    
    
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];

    CGContextSetTextDrawingMode (currentContext, kCGTextFill);

    NSString *sTemplateID = [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID];
    
    NSString *sPath = [NSString stringWithFormat:@"templateBg_%@.png", sTemplateID];
    UIImage *demoImage = [UIImage imageNamed:sPath];
    [demoImage drawInRect:CGRectMake(0, 05, pageRect.size.width, pageRect.size.height)];
    
    
    CGContextSetTextDrawingMode (currentContext, kCGTextFill);
    
    CGSize maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 50), 200);
    NSString *sStr;;
    CGSize expectedLabelSize;// = [sStr sizeWithFont:kINVOICE_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    
    
    CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kCOMPANY_NAME_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    sStr = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyName];//[self getKeyValueForID:@"companyName" Disc:keyDisc];
    expectedLabelSize = [sStr sizeWithFont:kCOMPANY_NAME_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
   
    CGContextSetRGBFillColor(currentContext, 0, 0, 0, 1.0);
    CGContextFillRect(currentContext, CGRectMake(0, fY, kPDF_MARGIN+expectedLabelSize.width+10, expectedLabelSize.height+10));
    
    fY+= 5;
    
    CGContextSetRGBFillColor(currentContext, 1, 1, 1, 1.0);
    [sStr drawInRect:CGRectMake(kPDF_MARGIN, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_NAME_FONT];
    
    fY+= 50+expectedLabelSize.height;
    

    sStr = @"Invoice";
    NSString *sType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];
    if([sType isEqualToString:@"inv"])
    {
        sStr = @"Invoice";
    }
    else if([sType isEqualToString:@"est"])
    {
        sStr = @"Estimate";
    }
    else if([sType isEqualToString:@"po"])
    {
        sStr = @"Purchase Order";
    }
    else if([sType isEqualToString:@"crn"])
    {
        sStr = @"Credit Memo";
    }

    
    CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kINVOICE_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    expectedLabelSize = [sStr sizeWithFont:kINVOICE_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    fX = (pageRect.size.width - kPDF_MARGIN*2)/2+50;
    [sStr drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, maximumLabelSize.height) withFont:kINVOICE_FONT lineBreakMode:NSLineBreakByWordWrapping alignment:NSTextAlignmentRight];

       
    fY += expectedLabelSize.height+10;
    y = fY;
    
    CGFloat height = [self getCompanyHeaderHeightForTemp3:pageRect DocumentDict:documentDict];
    
    CGContextSetRGBFillColor(currentContext, kHEADER_RECT_COLOR_RED1, kHEADER_RECT_COLOR_GREEN1, kHEADER_RECT_COLOR_BLUE1, 1.0);
    CGContextFillRect(currentContext, CGRectMake(5, fY, pageRect.size.width-10, height+20));
    
    NSString *skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress1];//@"companyAddress1"];//[self getKeyValueForID:@"companyAddress1" Disc:keyDisc];
        
    CGContextSelectFont (currentContext, kFONT_NAME, kCOMPANY_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_ADDR_FONT lineBreakMode:NSLineBreakByWordWrapping alignment:NSTextAlignmentRight];
    
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress2];//[self getKeyValueForID:@"companyAddress2" Disc:keyDisc];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_ADDR_FONT lineBreakMode:NSLineBreakByWordWrapping alignment:NSTextAlignmentRight];
    
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress3];//[self getKeyValueForID:@"companyAddress3" Disc:keyDisc];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_ADDR_FONT lineBreakMode:NSLineBreakByWordWrapping alignment:NSTextAlignmentRight];
    
    CGContextSelectFont (currentContext, kFONT_NAME, kCOMPANY_CONTACT_FONT_NUMBER, kCGEncodingMacRoman);
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact1];//[self getKeyValueForID:@"companyContact1" Disc:keyDisc];
    fY += expectedLabelSize.height+5;
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_CONTACT_FONT lineBreakMode:NSLineBreakByWordWrapping alignment:NSTextAlignmentRight];
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact2];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_CONTACT_FONT lineBreakMode:NSLineBreakByWordWrapping alignment:NSTextAlignmentRight];
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact3];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_CONTACT_FONT lineBreakMode:NSLineBreakByWordWrapping alignment:NSTextAlignmentRight];
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact4];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_CONTACT_FONT lineBreakMode:NSLineBreakByWordWrapping alignment:NSTextAlignmentRight];
    
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyContact5];//[self getKeyValueForID:@"companyContact2" Disc:keyDisc];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kCOMPANY_CONTACT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kCOMPANY_CONTACT_FONT lineBreakMode:NSLineBreakByWordWrapping alignment:NSTextAlignmentRight];
    
    x=kPDF_MARGIN;
    
    CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kDOCUMENT_INFO_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_DocumentNumber];
    skey = [NSString stringWithFormat:@"Invoice No:      %@", skey];
    maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 100), 200);
    expectedLabelSize = [skey sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    
    
    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_DocumentDate];//[self getKeyValueForID:@"documentDate" Disc:invoiceDict];
    y += expectedLabelSize.height;
    skey = [NSString stringWithFormat:@"Date:               %@", skey];
    expectedLabelSize = [skey sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    
    
    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_Terms];//[self getKeyValueForID:@"terms" Disc:invoiceDict];
    y += expectedLabelSize.height;
    skey = [NSString stringWithFormat:@"Terms:            %@", skey];
    expectedLabelSize = [skey sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    
    
    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kInvoice_DocumentDueDate];//[dateFormatter stringFromDate:dueDate];
    y += expectedLabelSize.height;
    skey = [NSString stringWithFormat:@"Due Date:       %@", skey];
    expectedLabelSize = [skey sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    
    y+= expectedLabelSize.height;
    
    if(fY>y)
    {
        return fY+15;
    }
    else
        return y+15;
}

- (CGFloat) createHeaderForTemplate4:(CGRect)pageRect context:(CGContextRef)currentContext DocumentDict:(NSMutableDictionary *)documentDict X:(CGFloat)fX Y:(CGFloat)fY
{
    CGFloat x = fX;
    CGFloat y;
    
    
    CGContextSetTextDrawingMode (currentContext, kCGTextFill);
    
    
    CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kINVOICE_FONT_NUMBER, kCGEncodingMacRoman);
    
    CGContextSetRGBFillColor(currentContext, (166.0/255.0), (45.0/255.0), (63.0/255.0), 1.0);
    CGContextSetTextDrawingMode (currentContext, kCGTextFill);
    
    CGSize maximumLabelSize = CGSizeMake(((pageRect.size.width-kPDF_MARGIN*2)/2 - 20), 200);
    NSString *sStr = @"Invoice";
    NSString *sType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];
    if([sType isEqualToString:@"inv"])
    {
        sStr = @"Invoice";
    }
    else if([sType isEqualToString:@"est"])
    {
        sStr = @"Estimate";
    }
    else if([sType isEqualToString:@"po"])
    {
        sStr = @"Purchase Order";
    }
    else if([sType isEqualToString:@"crn"])
    {
        sStr = @"Credit Memo";
    }

    
    CGSize expectedLabelSize = [sStr sizeWithFont:kINVOICE_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap ];
    
    
    fX = kPDF_MARGIN + maximumLabelSize.width+10;
    
    [sStr drawInRect:CGRectMake(pageRect.size.width-(kPDF_MARGIN+expectedLabelSize.width), fY, expectedLabelSize.width, maximumLabelSize.height) withFont:kINVOICE_FONT];
    
    fY += expectedLabelSize.height;
    
    fY+= 5;
    CGContextSetStrokeColorWithColor(currentContext, [UIColor colorWithRed:(166.0/255.0) green:(45.0/255.0) blue:(63.0/255.0) alpha:1.0].CGColor);
    
    //Set the width of the pen mark
    CGContextSetLineWidth(currentContext, 2.5);
    
    // Draw a line
    //Start at this point
    CGContextMoveToPoint(currentContext, kPDF_MARGIN, fY);
    
    //Give instructions to the CGContext
    //(move "pen" around the screen)
    CGContextAddLineToPoint(currentContext, pageRect.size.width-kPDF_MARGIN , fY);
    
    
    //Draw it
    CGContextStrokePath(currentContext);
    

    fY+= 5;
    y = fY;

    
    fY = [self createCompanyHeader:pageRect context:currentContext DocumentDict:documentDict X:x Y:fY];
    
    
    CGContextSelectFont (currentContext, kFONT_NAME, kDOCUMENT_INFO_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_GREEN_COLOR, 1.0);
    
    NSString *skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_DocumentNumber];//[self getKeyValueForID:@"documentNumber" Disc:invoiceDict];
    NSString *sTextToDraw;
    
    x = fX;
    
    //fY = y;
    sTextToDraw = [NSString stringWithFormat:@"Invoice No:      %@", skey];
    maximumLabelSize = CGSizeMake(((pageRect.size.width-kPDF_MARGIN*2)/2 - 100), 200);
    x = fX + 100;
    
    expectedLabelSize = [sTextToDraw sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sTextToDraw drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    
    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_DocumentDate];//[self getKeyValueForID:@"documentDate" Disc:invoiceDict];
    y += (expectedLabelSize.height+5);
    sTextToDraw = [NSString stringWithFormat:@"Date:                %@", skey];
    expectedLabelSize = [sTextToDraw sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    
    
    [sTextToDraw drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    
    
    if(fY>y)
    {
        return fY;
    }
    else
        return y;
    

}


- (CGFloat) createHeaderForTemplate5:(CGRect)pageRect context:(CGContextRef)currentContext DocumentDict:(NSMutableDictionary *)documentDict X:(CGFloat)fX Y:(CGFloat)fY
{
    CGFloat x = fX;
    CGFloat y;
    
    
    CGContextSetTextDrawingMode (currentContext, kCGTextFill);
    
    CGSize maximumLabelSize = CGSizeMake(((pageRect.size.width-kPDF_MARGIN*2)/2 - 50), 200);
    NSString *sStr = @"Tax Invoice";
    NSString *sType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];
    if([sType isEqualToString:@"inv"])
    {
        sStr = @"Tax Invoice";
    }
    else if([sType isEqualToString:@"est"])
    {
        sStr = @"Estimate";
    }
    else if([sType isEqualToString:@"po"])
    {
        sStr = @"Purchase Order";
    }
    else if([sType isEqualToString:@"crn"])
    {
        sStr = @"Credit Memo";
    }

    
    CGSize expectedLabelSize = [sStr sizeWithFont:kINVOICE_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap ];
    fX = pageRect.size.width-(kPDF_MARGIN+maximumLabelSize.width);
    
    CGContextSetRGBFillColor(currentContext, kHEADER_RECT_RED_TEMP5, kHEADER_RECT_GREEN_TEMP5, kHEADER_RECT_BLUE_TEMP5, 1.0);
    CGContextFillRect(currentContext, CGRectMake(fX, fY+2, maximumLabelSize.width, kHEADER_RECT_HEIGHT));
    
    
    CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kINVOICE_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kHEADER_TEXT_RED_TEMP5, kHEADER_TEXT_GREEN_TEMP5, kHEADER_TEXT_BLUE_TEMP5, 1.0);
    
    [sStr drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kINVOICE_FONT];

    
    fY += expectedLabelSize.height+5;
    

    
    NSString *sTextToDraw = @"Invoice no:";
    expectedLabelSize = [sTextToDraw sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sTextToDraw drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    //fX= pageRect.size.width- (kPDF_MARGIN+20+expectedLabelSize.width);
    fX+= expectedLabelSize.width+20;
    x=fX;
    
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    
    sTextToDraw = [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_DocumentNumber];
    expectedLabelSize = [sTextToDraw sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sTextToDraw drawInRect:CGRectMake(fX, fY+1, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    
    fY+= expectedLabelSize.height+2;
    fX = pageRect.size.width-(kPDF_MARGIN+maximumLabelSize.width);
    CGContextSetRGBFillColor(currentContext, kHEADER_TEXT_RED_TEMP5, kHEADER_TEXT_GREEN_TEMP5, kHEADER_TEXT_BLUE_TEMP5, 1.0);

    sTextToDraw = @"Date:";
    expectedLabelSize = [sTextToDraw sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sTextToDraw drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    //fX= pageRect.size.width- (kPDF_MARGIN+20+expectedLabelSize.width);
    fX = x;
    
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    
    sTextToDraw = [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_DocumentDate];
    expectedLabelSize = [sTextToDraw sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sTextToDraw drawInRect:CGRectMake(fX, fY+1, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    
    fY+= expectedLabelSize.height;
    fX = kPDF_MARGIN;

    maximumLabelSize = CGSizeMake(((pageRect.size.width-kPDF_MARGIN*2)/2 - 20), 200);
    y = fY;
    
    
    fY = [self createCompanyHeader:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
    return fY;
}

- (void) showPageNumber:(CGRect)pageRect context:(CGContextRef)currentContext DocumentDict:(NSMutableDictionary *)documentDict X:(CGFloat)fX Y:(CGFloat)fY showFooter:(BOOL)bFooter
{
    AppDelegate *appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    NSString *sTemplateID = [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID];
    CGSize maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 50), 200);
    CGSize expectedLabelSize ;
    maximumLabelSize.width = (pageRect.size.width-kPDF_MARGIN*2)/2+100 ;
    
    NSString *skey;
   
    if(bFooter)
    {
        fY = pageRect.size.height- ([self getFooterHeight:pageRect DocumentDict:documentDict] + 20);
    }
    else
    {
        fY =  pageRect.size.height- 50;
    }
    
    skey = [NSString stringWithFormat:@"Page:%d", nCurrentPage];
    
    CGContextSelectFont (currentContext, kFONT_NAME, kFOOTER_PAGE_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
    if(([sTemplateID isEqualToString:@"3"]) || ([sTemplateID isEqualToString:@"4"]))
    {
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    }
    else
    {
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    }
    
    expectedLabelSize = [skey sizeWithFont:kFOOTER_PAGE_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    
    fX = kPDF_MARGIN;
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_PAGE_TEXT_FONT];
    

    
}

- (void) createFooter:(CGRect)pageRect context:(CGContextRef)currentContext DocumentDict:(NSMutableDictionary *)documentDict X:(CGFloat)fX Y:(CGFloat)fY
{
    AppDelegate *appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    NSString *sTemplateID = [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID];
    CGSize maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 50), 200);
    CGSize expectedLabelSize ;
    maximumLabelSize.width = (pageRect.size.width-kPDF_MARGIN*2)/2+100 ;
    
    NSString *skey;
    CGFloat fFooterHeight = [self getFooterHeight:pageRect DocumentDict:documentDict];

    [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY showFooter:YES];

    CGContextSetLineWidth(currentContext, 1);
    if([sTemplateID isEqualToString:@"3"])
    {
        CGContextSetStrokeColorWithColor(currentContext, [UIColor blackColor].CGColor);
    }
    else
    {
        CGContextSetStrokeColorWithColor(currentContext, [UIColor grayColor].CGColor);
    }
    
    
    CGPoint startPoint = CGPointMake(kPDF_MARGIN, pageRect.size.height-(fFooterHeight+5));
    CGPoint endPoint = CGPointMake(pageRect.size.width - kPDF_MARGIN, pageRect.size.height-(fFooterHeight+5));
    
    CGContextBeginPath(currentContext);
    CGContextMoveToPoint(currentContext, startPoint.x, startPoint.y);
    CGContextAddLineToPoint(currentContext, endPoint.x, endPoint.y);
    
    CGContextClosePath(currentContext);
    CGContextDrawPath(currentContext, kCGPathFillStroke);
    
    
    
    
    skey = [NSString stringWithFormat:@"REMITTANCE ADVICE FOR invoice #%@ on %@", [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_DocumentNumber], [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_DocumentDate]];
    
    CGContextSelectFont (currentContext, kFONT_NAME, kFOOTER_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
    if(([sTemplateID isEqualToString:@"3"]) || ([sTemplateID isEqualToString:@"4"]))
    {
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    }
    else
    {
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    }
    
    
    fY+= expectedLabelSize.height;
    
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    
    fX = kPDF_MARGIN;
    fY = pageRect.size.height- [self getFooterHeight:pageRect DocumentDict:documentDict];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_TEXT_FONT];
    
    
    fY+= expectedLabelSize.height;
    skey = [NSString stringWithFormat:@"Received From:          %@", [[invoiceDict valueForKey:kInvoice_CLIENTINFO]  valueForKey:kDbInvoice_ClientName]];
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_TEXT_FONT];
    
    
    fY+= expectedLabelSize.height;
    
    NSLocale *theLocale = [NSLocale currentLocale];
    NSString *currencySymbol = [theLocale objectForKey:NSLocaleCurrencySymbol];

    skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, [[[invoiceDict valueForKey:kInvoice_CALCULATIONINFO]  valueForKey:kInvoice_BalanceDue] floatValue]];//[NSString stringWithFormat:@"Rs %.1f", fSubTotal];
    
    skey = [NSString stringWithFormat:@"Balance Due:          %@", skey];
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_TEXT_FONT];
    
    
    fY+= expectedLabelSize.height;
    
    skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, [[[invoiceDict valueForKey:kInvoice_CALCULATIONINFO] valueForKey:kDbInvoice_PartPayment] floatValue]];//[NSString stringWithFormat:@"Rs %.1f", fSubTotal];

    
    skey = [NSString stringWithFormat:@"Amount Paid:          %@", skey];
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_TEXT_FONT];
    
    
    maximumLabelSize.width = (pageRect.size.width-kPDF_MARGIN*2)/2-100 ;
    skey = [NSString stringWithFormat:@"Please detach and send with remittance to: %@", [appdelegate.settingsDict valueForKey:kDbKeyValue_companyName]];
    
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    
    fX =kPDF_MARGIN + (pageRect.size.width-kPDF_MARGIN*2)/2+100 ;
    fY = pageRect.size.height- [self getFooterHeight:pageRect DocumentDict:documentDict];
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_TEXT_FONT];
    
    fY += expectedLabelSize.height;
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress1];//[self getKeyValueForID:@"companyAddress1" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_TEXT_FONT];
    
    fY += expectedLabelSize.height;
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress2];//[self getKeyValueForID:@"companyAddress2" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_TEXT_FONT];
    
    
    fY += expectedLabelSize.height;
    skey = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyAddress3];//[self getKeyValueForID:@"companyAddress3" Disc:keyDisc];
    expectedLabelSize = [skey sizeWithFont:kFOOTER_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_TEXT_FONT];

}

- (CGFloat) createCalculation:(CGRect)pageRect context:(CGContextRef)currentContext DocumentDict:(NSMutableDictionary *)documentDict X:(CGFloat)fX Y:(CGFloat)fY
{
    NSLocale *theLocale = [NSLocale currentLocale];
    NSString *currencySymbol = [theLocale objectForKey:NSLocaleCurrencySymbol];
    
    AppDelegate *appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    NSString *sTemplateID = [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID];
    NSString *sDocumentType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];

    
    ////////////////////////
    //check that whole calculation will come on the same page or not
    ////////////////////////
    if((fY+160) >= (pageRect.size.height-[self getFooterHeight:pageRect DocumentDict:documentDict]))
    {
        fY+= 160;
        fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    }
    
    if([sTemplateID isEqualToString:@"3"])
    {
        CGContextSetStrokeColorWithColor(currentContext, [UIColor colorWithRed:kTEXT_RED_COLOR_TEMP4 green:kTEXT_GREEN_COLOR_TEMP4 blue:kTEXT_BLUE_COLOR_TEMP4 alpha:1.0].CGColor);
    
        CGContextSetLineWidth(currentContext, 2);
    }
    else
    {
        CGContextSetStrokeColorWithColor(currentContext, [UIColor blackColor].CGColor);
        CGContextSetLineWidth(currentContext, 1);

    }
    
    CGPoint startPoint = CGPointMake(kPDF_MARGIN, fY);
    CGPoint endPoint = CGPointMake(pageRect.size.width - kPDF_MARGIN, fY);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    float dash[2]={2 ,3}; // pattern 6 times “solid”, 5 times “empty”
    
    CGContextSetLineDash(context,0,dash,1);
    
    
    CGContextBeginPath(currentContext);
    CGContextMoveToPoint(currentContext, startPoint.x, startPoint.y);
    CGContextAddLineToPoint(currentContext, endPoint.x, endPoint.y);
    
    CGContextClosePath(currentContext);
    CGContextDrawPath(currentContext, kCGPathFillStroke);
    
    fY+= 10;
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];

    CGSize maximumLabelSize = CGSizeMake(200, 200);
    NSString *skey = [NSString stringWithFormat:@"Subtotal:"];
    
    CGContextSelectFont (currentContext, kFONT_NAME, kSUBTOTAL_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    
    CGSize expectedLabelSize = [skey sizeWithFont:kSUBTOTAL_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    fX = pageRect.size.width/2+100-expectedLabelSize.width;
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kSUBTOTAL_TEXT_FONT];
    
    skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, [[[invoiceDict valueForKey:kInvoice_CALCULATIONINFO] valueForKey:kDbInvoice_Subtotal] floatValue]];//[NSString stringWithFormat:@"Rs %.1f", fSubTotal];
    expectedLabelSize = [skey sizeWithFont:kSUBTOTAL_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    fX = pageRect.size.width-(50+ expectedLabelSize.width);
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kSUBTOTAL_TEXT_FONT];
    fY += expectedLabelSize.height+5;
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    
    
    CGContextSelectFont (currentContext, kFONT_NAME, kTAX_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    
    skey = [NSString stringWithFormat:@"TAX:"];
    expectedLabelSize = [skey sizeWithFont:kTAX_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    fX = pageRect.size.width/2+100-expectedLabelSize.width;
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kTAX_FONT];
    
    skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, [[[invoiceDict valueForKey:kInvoice_CALCULATIONINFO] valueForKey:kDbInvoice_TaxAmount] floatValue]];//[NSString stringWithFormat:@"Rs %.1f", fSubTotal];
    expectedLabelSize = [skey sizeWithFont:kTAX_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    fX = pageRect.size.width-(50+ expectedLabelSize.width);
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kTAX_FONT];
    fY += expectedLabelSize.height+5;
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    
    if([sDocumentType isEqualToString:@"inv"])
    {
        CGContextSelectFont (currentContext, kFONT_NAME, kSHIPPING_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
        
        skey = [NSString stringWithFormat:@"Shipping:"];
        expectedLabelSize = [skey sizeWithFont:kSHIPPING_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        fX = pageRect.size.width/2+100-expectedLabelSize.width;
        [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kSHIPPING_FONT];
        
        skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, [[[invoiceDict valueForKey:kInvoice_SHIPPINGINFO] valueForKey:kDbInvoice_ShippingAmount] floatValue]];//[NSString stringWithFormat:@"Rs %.1f", fSubTotal];
        expectedLabelSize = [skey sizeWithFont:kSHIPPING_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        fX = pageRect.size.width-(50+ expectedLabelSize.width);
        fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
        [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kSHIPPING_FONT];
        fY += expectedLabelSize.height+5;
        fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    }
    
    
    CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kTOTAL_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    
    skey = [NSString stringWithFormat:@"Total:"];
    expectedLabelSize = [skey sizeWithFont:kTOTAL_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    fX = pageRect.size.width/2+100-expectedLabelSize.width;
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kTOTAL_TEXT_FONT];
    
    skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, [[[invoiceDict valueForKey:kInvoice_CALCULATIONINFO] valueForKey:kDbInvoice_Total] floatValue]];//[NSString stringWithFormat:@"Rs %.1f", fSubTotal];
    expectedLabelSize = [skey sizeWithFont:kTOTAL_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    fX = pageRect.size.width-(50+ expectedLabelSize.width);
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kTOTAL_TEXT_FONT];
    fY += expectedLabelSize.height+5;
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    
    if([sDocumentType isEqualToString:@"inv"])
    {
        CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kPAID_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
        
        skey = [NSString stringWithFormat:@"Paid:"];
        expectedLabelSize = [skey sizeWithFont:kPAID_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        fX = pageRect.size.width/2+100-expectedLabelSize.width;
        [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kPAID_TEXT_FONT];
        
        skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, [[[invoiceDict valueForKey:kInvoice_CALCULATIONINFO] valueForKey:kDbInvoice_PartPayment] floatValue]];//[NSString stringWithFormat:@"Rs %.1f", fSubTotal];
        expectedLabelSize = [skey sizeWithFont:kPAID_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        fX = pageRect.size.width-(50+ expectedLabelSize.width);
        [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kPAID_TEXT_FONT];
        fY += expectedLabelSize.height+5;
        fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    
    
    CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kBALANCE_DUE_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    
    skey = [NSString stringWithFormat:@"Balance Due:"];
    expectedLabelSize = [skey sizeWithFont:kBALANCE_DUE_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    fX = pageRect.size.width/2+100-expectedLabelSize.width;
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kBALANCE_DUE_TEXT_FONT];
    
    skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, [[[invoiceDict valueForKey:kInvoice_CALCULATIONINFO]  valueForKey:kInvoice_BalanceDue] floatValue]];//[NSString stringWithFormat:@"Rs %.1f", fSubTotal];
    expectedLabelSize = [skey sizeWithFont:kBALANCE_DUE_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    fX = pageRect.size.width-(50+ expectedLabelSize.width);
    [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kBALANCE_DUE_TEXT_FONT];
    fY += expectedLabelSize.height+5;
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    }
    
    if([sTemplateID isEqualToString:@"3"])
    {
        CGContextSetStrokeColorWithColor(currentContext, [UIColor colorWithRed:kTEXT_RED_COLOR_TEMP4 green:kTEXT_GREEN_COLOR_TEMP4 blue:kTEXT_BLUE_COLOR_TEMP4 alpha:1.0].CGColor);
        
        CGContextSetLineWidth(currentContext, 2);
    }
    else
    {
        CGContextSetStrokeColorWithColor(currentContext, [UIColor blackColor].CGColor);
        CGContextSetLineWidth(currentContext, 1);
        
    }
    fY+= expectedLabelSize.height;
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    
    
    startPoint = CGPointMake(kPDF_MARGIN, fY);
    endPoint = CGPointMake(pageRect.size.width - kPDF_MARGIN, fY);
    
    CGContextBeginPath(currentContext);
    CGContextMoveToPoint(currentContext, startPoint.x, startPoint.y);
    CGContextAddLineToPoint(currentContext, endPoint.x, endPoint.y);
    
    CGContextClosePath(currentContext);
    CGContextDrawPath(currentContext, kCGPathFillStroke);
    
    return fY;

}


- (CGFloat) createShippingInfo:(CGRect)pageRect context:(CGContextRef)currentContext DocumentDict:(NSMutableDictionary *)documentDict X:(CGFloat)fX Y:(CGFloat)fY showRect:(BOOL)bshowRect
{
    CGPoint startPoint = CGPointMake(fX, fY);
    CGFloat filler = 10;
    CGFloat fShippingInfoHeight = fY;
    
    CGSize maximumLabelSize = CGSizeMake(((pageRect.size.width-(kPDF_MARGIN*2+(filler*3)))/4), 200);
    NSString *sStr = @""; //= @"INVOICE";
    CGSize expectedLabelSize ;
    AppDelegate *appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    NSString *sTemplateID = [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID];


    if(bshowRect)
    {
        if([sTemplateID isEqualToString:@"4"])
        {
            CGContextSetRGBFillColor(currentContext, kHEADER_RECT_RED_TEMP5, kHEADER_RECT_GREEN_TEMP5, kHEADER_RECT_BLUE_TEMP5, 1.0);
        }
        else
        {
            CGContextSetRGBFillColor(currentContext, kHEADER_RECT_COLOR_RED, kHEADER_RECT_COLOR_GREEN, kHEADER_RECT_COLOR_BLUE, 1.0);
        }
        CGContextFillRect(currentContext, CGRectMake(fX, startPoint.y+2, pageRect.size.width-kPDF_MARGIN*2, kHEADER_RECT_HEIGHT));
    }
    
    float fheaderItemWidth = ((pageRect.size.width-(kPDF_MARGIN*2+(filler*3)))/4);
    
    float shippingX = fX+10;;
    
    fY += 5;
    
    CGContextSelectFont (currentContext, kFONT_NAME, kTRACKING_INFO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
    if([sTemplateID isEqualToString:@"3"])
    {
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    }
    else if([sTemplateID isEqualToString:@"4"])
    {
        CGContextSetRGBFillColor(currentContext, kHEADER_TEXT_RED_TEMP5, kHEADER_TEXT_GREEN_TEMP5, kHEADER_TEXT_BLUE_TEMP5, 1.0);
    }
    else
    {
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    }
    
    
    expectedLabelSize = [sStr sizeWithFont:kTRACKING_INFO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [@"Tracking No" drawInRect:CGRectMake(shippingX, fY, fheaderItemWidth, expectedLabelSize.height) withFont:kTRACKING_INFO_HEADER_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
    
    shippingX += (fheaderItemWidth+filler);
    [@"Ship Date" drawInRect:CGRectMake(shippingX, fY, fheaderItemWidth, expectedLabelSize.height) withFont:kTRACKING_INFO_HEADER_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
    
    shippingX += (fheaderItemWidth+filler);
    [@"Ship Via" drawInRect:CGRectMake(shippingX, fY, fheaderItemWidth, expectedLabelSize.height) withFont:kTRACKING_INFO_HEADER_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
    
    shippingX += (fheaderItemWidth+filler);
    [@"FOB" drawInRect:CGRectMake(shippingX, fY, fheaderItemWidth, expectedLabelSize.height) withFont:kTRACKING_INFO_HEADER_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
    
    
    shippingX = fX+10;
    fY += kHEADER_RECT_HEIGHT+5;
    fShippingInfoHeight = 0;;
    
    
    CGContextSelectFont (currentContext, kFONT_NAME, kTRACKING_INFO_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
    if(([sTemplateID isEqualToString:@"3"]) || ([sTemplateID isEqualToString:@"4"]))
    {
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    }
    else
    {
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    }
    
    NSString *skey = [[invoiceDict valueForKey:kInvoice_SHIPPINGINFO] valueForKey:kDbInvoice_ShippingTrackingNo];//[self getKeyValueForID:@"shippingTrackingNo" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kTRACKING_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(shippingX, fY, fheaderItemWidth, expectedLabelSize.height) withFont:kTRACKING_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
    
    
    shippingX += (fheaderItemWidth+filler);
    fShippingInfoHeight = expectedLabelSize.height;
    
    skey = [[invoiceDict valueForKey:kInvoice_SHIPPINGINFO] valueForKey:kDbInvoice_ShippingDate];//[self getKeyValueForID:@"shippingDate" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kTRACKING_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(shippingX, fY, fheaderItemWidth, expectedLabelSize.height) withFont:kTRACKING_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
    
    shippingX += (fheaderItemWidth+filler);
    if(expectedLabelSize.height > fShippingInfoHeight)
    {
        fShippingInfoHeight = expectedLabelSize.height;
    }
    
    
    skey = [[invoiceDict valueForKey:kInvoice_SHIPPINGINFO] valueForKey:kDbInvoice_ShippingVia];//[self getKeyValueForID:@"shippingVia" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kTRACKING_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(shippingX, fY, fheaderItemWidth, expectedLabelSize.height) withFont:kTRACKING_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
    
    shippingX += (fheaderItemWidth+filler);
    if(expectedLabelSize.height > fShippingInfoHeight)
    {
        fShippingInfoHeight = expectedLabelSize.height;
    }
    
    skey = [[invoiceDict valueForKey:kInvoice_SHIPPINGINFO] valueForKey:kDbInvoice_ShippingFOB];//[self getKeyValueForID:@"shippingFOB" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kTRACKING_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(shippingX, fY, fheaderItemWidth, expectedLabelSize.height) withFont:kTRACKING_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
    
    if(expectedLabelSize.height > fShippingInfoHeight)
    {
        fShippingInfoHeight = expectedLabelSize.height;
    }
    
    fY+= fShippingInfoHeight;
    return fY;
}

- (CGFloat)createItemHeader:(CGRect)pageRect context:(CGContextRef)currentContext fy:(CGFloat)fY fx:(CGFloat)fx showLine:(BOOL)bshowLine showRect:(BOOL)bshowRect
{
    CGFloat fX = fx+10;;
    fY += 5;;
    CGPoint startPoint = CGPointMake(fx, fY);
    AppDelegate *appdelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    NSString *sTemplateID = [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID];
    

    if(bshowRect)
    {
        if([sTemplateID isEqualToString:@"4"])
        {
            CGContextSetRGBFillColor(currentContext, kHEADER_RECT_RED_TEMP5, kHEADER_RECT_GREEN_TEMP5, kHEADER_RECT_BLUE_TEMP5, 1.0);
        }
        else
        {
            CGContextSetRGBFillColor(currentContext, kHEADER_RECT_COLOR_RED, kHEADER_RECT_COLOR_GREEN, kHEADER_RECT_COLOR_BLUE, 1.0);
        }
        CGContextFillRect(currentContext, CGRectMake(fx, startPoint.y+2, pageRect.size.width-fx*2, kHEADER_RECT_HEIGHT));
    }
   
    CGContextSelectFont (currentContext, kFONT_NAME, kITEM_INFO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
    if([sTemplateID isEqualToString:@"3"])
    {
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR_TEMP4, kTEXT_GREEN_COLOR_TEMP4, kTEXT_BLUE_COLOR_TEMP4, 1.0);
    }
    else if([sTemplateID isEqualToString:@"4"])
    {
        CGContextSetRGBFillColor(currentContext, kHEADER_TEXT_RED_TEMP5, kHEADER_TEXT_GREEN_TEMP5, kHEADER_TEXT_BLUE_TEMP5, 1.0);
    }
    else
    {
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    }
    if(bshowLine)
    {
        [self createLine:currentContext startPoint:CGPointMake(kPDF_MARGIN, fY+2) endPoint:CGPointMake(pageRect.size.width-kPDF_MARGIN, fY+2)];
        [self createLine:currentContext startPoint:CGPointMake(kPDF_MARGIN, fY+2) endPoint:CGPointMake(kPDF_MARGIN, fY+kHEADER_RECT_HEIGHT+2)];
        [self createLine:currentContext startPoint:CGPointMake(pageRect.size.width-kPDF_MARGIN, fY+2) endPoint:CGPointMake(pageRect.size.width-kPDF_MARGIN, fY+2+kHEADER_RECT_HEIGHT)];
    }
    CGFloat filler = 5.0;
    

    NSString *sShow = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowQtyRateFields];
    BOOL bQtyRate = ([sShow isEqualToString:@"Y"])? YES:NO;
    
    sShow = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowCodeField];
    BOOL bCode = ([sShow isEqualToString:@"Y"])? YES:NO;
    
    sShow = [[invoiceDict valueForKey:kInvoice_TAXINFO] valueForKey:kDbInvoice_TaxType];//[appdelegate.settingsDict valueForKey:kDbKeyValue_companyTaxOption];
    BOOL bTax = ([sShow isEqualToString:@"1"])?YES:NO;
    
    sShow = [[invoiceDict valueForKey:kInvoice_DISCOUNTINFO] valueForKey:kDbInvoice_DiscountType];//[appdelegate.settingsDict valueForKey:kDbKeyValue_companyDiscountOption];
    BOOL bDiscount = ([sShow isEqualToString:@"2"])?YES:NO;
    
    if(bCode)
    {
        [@"Code" drawInRect:CGRectMake(fX, fY+5, dblCodeWidth, 14.0) withFont:kITEM_INFO_HEADER_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentLeft];
        fX += dblCodeWidth+(filler/2);
        if(bshowLine)
        {
            [self createLine:currentContext startPoint:CGPointMake(fX, fY+2) endPoint:CGPointMake(fX, fY+2+kHEADER_RECT_HEIGHT)];
        }
        fX += filler/2;
    }
    
    [@"Description" drawInRect:CGRectMake(fX, fY+5, dblDescWidth, 14.0) withFont:kITEM_INFO_HEADER_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentLeft];
    fX += dblDescWidth+(filler/2);
    if(bshowLine)
    {
        [self createLine:currentContext startPoint:CGPointMake(fX, fY+2) endPoint:CGPointMake(fX, fY+2+kHEADER_RECT_HEIGHT)];
    }
    fX += filler/2;
    
    if(bQtyRate)
    {
        [@"Quantity" drawInRect:CGRectMake(fX, fY+5, dblQtyWidth, 14.0) withFont:kITEM_INFO_HEADER_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentRight];
        fX += dblQtyWidth+(filler/2);
        if(bshowLine)
        {
            [self createLine:currentContext startPoint:CGPointMake(fX, fY+2) endPoint:CGPointMake(fX, fY+2+kHEADER_RECT_HEIGHT)];
        }
        fX += filler/2;

        
        [@"Rate" drawInRect:CGRectMake(fX, fY+5, dblRateWidth, 14.0) withFont:kITEM_INFO_HEADER_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentRight];
        fX += dblRateWidth+(filler/2);
        if(bshowLine)
        {
            [self createLine:currentContext startPoint:CGPointMake(fX, fY+2) endPoint:CGPointMake(fX, fY+2+kHEADER_RECT_HEIGHT)];
        }
        fX += filler/2;
    }
    
    if(bDiscount)
    {
        [@"Discount %" drawInRect:CGRectMake(fX, fY+5, dblDiscountWidth, 14.0) withFont:kITEM_INFO_HEADER_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentRight];
        fX += dblDiscountWidth+(filler/2);
        if(bshowLine)
        {
            [self createLine:currentContext startPoint:CGPointMake(fX, fY+2) endPoint:CGPointMake(fX, fY+2+kHEADER_RECT_HEIGHT)];
        }
        fX += filler/2;
    }
    
    if(bTax)
    {
        [@"Tax %" drawInRect:CGRectMake(fX, fY+5, dblTaxWidth, 14.0) withFont:kITEM_INFO_HEADER_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentRight];
        fX += dblTaxWidth+(filler/2);
        if(bshowLine)
        {
            [self createLine:currentContext startPoint:CGPointMake(fX, fY+2) endPoint:CGPointMake(fX, fY+2+kHEADER_RECT_HEIGHT)];
        }
        fX += filler/2;
    }
    
    [@"Amount" drawInRect:CGRectMake(fX, fY+5, dblAmountWidth, 14.0) withFont:kITEM_INFO_HEADER_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentRight];
    if(bshowLine)
    {
        [self createLine:currentContext startPoint:CGPointMake(kPDF_MARGIN, fY+kHEADER_RECT_HEIGHT+2) endPoint:CGPointMake(pageRect.size.width-kPDF_MARGIN, fY+kHEADER_RECT_HEIGHT+2)];
    }

    
    return fY+kHEADER_RECT_HEIGHT;
}


- (void)setItemTableColumnWidth:(CGRect)pageRect
{
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    CGSize maximumLabelSize;
    NSString *skey; //= @"INVOICE";
    CGSize expectedLabelSize ;
    
    
    NSInteger nNoOfColomn = 7;
    float filler = 5.0;
    
    
    NSString *sShow = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowQtyRateFields];
    bShowQtyRate = ([sShow isEqualToString:@"Y"])? YES:NO;
    if(bShowQtyRate == NO)
    {
        nNoOfColomn -= 2;
        dblQtyWidth = 0;
        dblRateWidth = 0;
    }
    
    sShow = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowCodeField];
    bShowCode = ([sShow isEqualToString:@"Y"])? YES:NO;
    if(bShowCode == NO)
    {
        nNoOfColomn -= 1;
        dblCodeWidth = 0;
    }
    
    sShow = [[invoiceDict valueForKey:kInvoice_TAXINFO] valueForKey:kDbInvoice_TaxType];
    bShowTax = ([sShow isEqualToString:@"1"])?YES:NO;
    if(bShowTax == NO)
    {
        nNoOfColomn -= 1;
        dblTaxWidth = 0;
    }
    
    sShow = [[invoiceDict valueForKey:kInvoice_DISCOUNTINFO] valueForKey:kDbInvoice_DiscountType];
    bShowDiscount = ([sShow isEqualToString:@"2"])?YES:NO;
    if(bShowDiscount == NO)
    {
        nNoOfColomn -= 1;
        dblDiscountWidth = 0;
    }

    
    skey = @"999999999999999";
    maximumLabelSize = CGSizeMake(200, 200);
    expectedLabelSize = [skey sizeWithFont:kITEM_INFO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeCharacterWrap];
    dblAmountWidth = expectedLabelSize.width;
    
    if(bShowQtyRate)
    {
        skey = @"000000000000";
        maximumLabelSize = CGSizeMake(200, 200);
        expectedLabelSize = [skey sizeWithFont:kITEM_INFO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeCharacterWrap];
        dblRateWidth = expectedLabelSize.width;
        
        skey = @"Quantity";
        maximumLabelSize = CGSizeMake(250, 200);
        expectedLabelSize = [skey sizeWithFont:kITEM_INFO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeCharacterWrap];
        dblQtyWidth = expectedLabelSize.width;
    }
    
    if(bShowDiscount)
    {
        skey = @"Discount";
        maximumLabelSize = CGSizeMake(1000, 200);
        expectedLabelSize = [skey sizeWithFont:kITEM_INFO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeCharacterWrap];
        dblDiscountWidth = expectedLabelSize.width;
    }
    if(bShowTax)
    {
        skey = @"000000";
        maximumLabelSize = CGSizeMake(1000, 200);
        expectedLabelSize = [skey sizeWithFont:kITEM_INFO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeCharacterWrap];
        dblTaxWidth = expectedLabelSize.width;
    }
    double dblTotalWidth = dblAmountWidth+ dblDiscountWidth + dblTaxWidth + dblQtyWidth + dblRateWidth;
   /* if(bShowQtyRate)
    {
        dblTotalWidth += filler*4;
    }
    else
    {
        dblTotalWidth += filler*2;
    }*/
    
    dblTotalWidth += (nNoOfColomn-1)*filler;
    
    double remain = ((pageRect.size.width- (kPDF_MARGIN*2+20)) - dblTotalWidth);
    if(bShowCode)
    {
        //remain -= filler*2;
        dblCodeWidth = .40*remain;
        dblDescWidth = .60*remain;
    }
    else
    {
        dblCodeWidth = 0;
        dblDescWidth = remain - filler;
    }

}

- (NSString *)getPdfFileName:(NSMutableDictionary *)documentDict
{
    NSString *filename = @"";
    NSString *sDocumentNo = [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_DocumentNumber];
    NSString *sType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];
    
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    if([sType isEqualToString:@"inv"])
    {
        filename = [NSString stringWithFormat:@"Invoice %@_Template%@.pdf", sDocumentNo, [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID]];
    }
    else if([sType isEqualToString:@"est"])
    {
        filename = [NSString stringWithFormat:@"Estimate %@_Template%@.pdf", sDocumentNo, [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID]];
    }
    else if([sType isEqualToString:@"po"])
    {
        filename = [NSString stringWithFormat:@"PurchaseOrder %@_Template%@.pdf", sDocumentNo, [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID]];
    }
    else if([sType isEqualToString:@"crn"])
    {
        filename = [NSString stringWithFormat:@"CreditNote %@_Template%@.pdf", sDocumentNo, [appdelegate.settingsDict valueForKey:kDbKeyValue_templateID]];
    }
    
    return filename;
}


- (void)createFirstPDF:(NSMutableDictionary *)documentDict
{
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    nCurrentPage = 0;
    
    NSLocale *theLocale = [NSLocale currentLocale];
    NSString *currencySymbol = [theLocale objectForKey:NSLocaleCurrencySymbol];
    
    CGRect pageRect = CGRectMake(0, 0, 611, 794);
    
    NSString *filename = [self getPdfFileName:invoiceDict];
    NSString *pdfFileName = [kDocumentsDirectory stringByAppendingPathComponent:filename];

    
    CGRect pdfRect = CGRectMake(0, 0, pageRect.size.width*2, pageRect.size.height*2);
    UIGraphicsBeginPDFContextToFile(pdfFileName, pdfRect, nil);
        
    UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, pageRect.size.width, pageRect.size.height), nil);
    nCurrentPage++;
    
    CGContextRef    currentContext = UIGraphicsGetCurrentContext();
    CGContextSetRGBFillColor(currentContext, 0.0, 0.0, 0.0, 1.0);
    
    
    CGFloat fX = kPDF_MARGIN;
    CGFloat fY = 80;
    CGFloat x;
    CGFloat y;
    
    fY = [self createHeader:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
    
    ///*
    NSString *skey ;

    CGSize maximumLabelSize = CGSizeMake(pageRect.size.width/2, 200);
    NSString *sStr; //= @"INVOICE";
    CGSize expectedLabelSize ;
    
    fY+= 50;
    
    CGFloat fRectX = fX;
    CGFloat fRectY = fY;
    

    sStr = @"Bill To:";
    
    CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    expectedLabelSize = [sStr sizeWithFont:kBILLTOSHIPTO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sStr drawInRect:CGRectMake(fX+10, fY+10, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_HEADER_FONT];
    
    
    fY += 10;
    y= fY;
    x = 100;
    
    maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 120), 500);
    CGContextSelectFont (currentContext, kFONT_NAME, kBILL_CUSTOMER_NAME_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO]  valueForKey:kDbInvoice_ClientName];//[self getKeyValueForID:@"contactName" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kBILL_CUSTOMER_NAME_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILL_CUSTOMER_NAME_FONT];
    
    CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine1];//[self getKeyValueForID:@"addressLine1" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine2];//[self getKeyValueForID:@"addressLine2" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    

    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine3];//[self getKeyValueForID:@"addressLine3" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    fY += expectedLabelSize.height;
    
    
    NSString *sDocumentType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];
    
    if([sDocumentType isEqualToString:@"inv"])
    {
        
        x = pageRect.size.width/2;
        
        
        sStr = @"Ship To:";
        CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
        
        expectedLabelSize = [sStr sizeWithFont:kBILLTOSHIPTO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
        [sStr drawInRect:CGRectMake(x, y, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_HEADER_FONT];
        x += 100;
        
        CGContextSelectFont (currentContext, kFONT_NAME, kSHIP_CUSTOMER_ADDR1_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine1];//[self getKeyValueForID:@"shippingAddressLine1" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kSHIP_CUSTOMER_ADDR1_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, expectedLabelSize.width, expectedLabelSize.height) withFont:kSHIP_CUSTOMER_ADDR1_FONT];
        y += expectedLabelSize.height;
        
        CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
        
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine2];//[self getKeyValueForID:@"shippingAddressLine2" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
        y += expectedLabelSize.height;
        
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine3];//[self getKeyValueForID:@"shippingAddressLine3" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    }
    
    CGFloat fRectHeight;
    if(fY > y)
        fRectHeight = fY - fRectY;
    else
        fRectHeight = y - fRectY;
    
    [self drawRect:CGRectMake(fRectX, fRectY, (pageRect.size.width- (fRectX*2)), fRectHeight) pdfContext:currentContext];

    fY = fRectY + fRectHeight;
    
    if([sDocumentType isEqualToString:@"inv"])
    {
        NSString *sShipping = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowShipping];
        
        if([sShipping isEqualToString:@"Y"])
        {
            fY += 20;
            fY = [self createShippingInfo:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY showRect:YES];
        }
    }
    else
    {
        fY += 10;
    }
    
    NSMutableArray *arrItem  = nil;
    
    if([[invoiceDict allKeys] containsObject:kInvoice_ITEMSLIST])
    {
        arrItem = [invoiceDict valueForKey:kInvoice_ITEMSLIST];
    }
    CGFloat fSubTotal = 0;

    if([arrItem count] >0)
    {
        [self setItemTableColumnWidth:pageRect];
        
        float filler = 5.0;
        bItem = YES;
        fY = [self createItemHeader:pageRect context:currentContext fy:fY fx:fX showLine:NO showRect:YES];
        
        fX = kPDF_MARGIN+10;
        fY = fY+10;
        
        for(int i=0 ; i<[arrItem count] ; i++)
        {
            NSMutableDictionary *dict = [arrItem objectAtIndex:i];
            fX = kPDF_MARGIN+10;
            
            fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
            CGFloat fItemInfoHeight = 0;

            CGContextSelectFont (currentContext, kFONT_NAME, kITEM_INFO_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
            CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
            
            if(bShowCode)
            {
                maximumLabelSize = CGSizeMake(dblCodeWidth, 100);
                skey = [dict valueForKey:kDbItem_Code];//[self getKeyValueForID:@"code" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeCharacterWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentLeft];
                
                fX += dblCodeWidth+filler;
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            
            maximumLabelSize = CGSizeMake(dblDescWidth, 100);
            skey = [dict valueForKey:kDbItem_Description];//[self getKeyValueForID:@"description" Disc:dict];
            expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
            [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
            
            fX += dblDescWidth+filler;
            if(expectedLabelSize.height> fItemInfoHeight)
            {
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            if(bShowQtyRate)
            {
                maximumLabelSize = CGSizeMake(dblQtyWidth, 21);
                skey = [dict valueForKey:kDbItem_Quantity];//[self getKeyValueForID:@"quantity" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:[UIFont systemFontOfSize:10]   lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblQtyWidth+filler;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
                
                
                maximumLabelSize = CGSizeMake(dblRateWidth, 21);
                skey = [NSString stringWithFormat:@"%@ %@", currencySymbol, [dict valueForKey:kDbItem_Rate]];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblRateWidth+filler;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            if(bShowDiscount)
            {
                maximumLabelSize = CGSizeMake(dblDiscountWidth, 21);
                skey = [dict valueForKey:kDbItem_DiscountRate];//[self getKeyValueForID:@"discountrate" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblDiscountWidth+filler;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            if(bShowTax)
            {
                maximumLabelSize = CGSizeMake(dblTaxWidth, 21);
                skey = [dict valueForKey:kDbItem_TaxRateMulti];//[self getKeyValueForID:@"taxratemulti" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblTaxWidth+filler;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            maximumLabelSize = CGSizeMake(dblAmountWidth, 21);
            
            double rate = [[dict valueForKey:kDbItem_Rate] doubleValue];
            double quantity = [[dict valueForKey:kDbItem_Quantity] doubleValue];
            double amout = rate*quantity;
            fSubTotal += amout;
            
            skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, amout];
            
            expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
            [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
            if(expectedLabelSize.height> fItemInfoHeight)
            {
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            fY += fItemInfoHeight+10;
        }
    
    }
    
    bItem = NO;
    
    CGContextSelectFont (currentContext, kFONT_NAME, kFOOTER_PAGE_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    maximumLabelSize = CGSizeMake(pageRect.size.width-kPDF_MARGIN, 100);

    skey = [NSString stringWithFormat:@"* Indicates non-taxable items"];
    
    expectedLabelSize = [skey sizeWithFont:kFOOTER_PAGE_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(kPDF_MARGIN, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_PAGE_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
    
    CGContextSetLineWidth(currentContext, 1);
    
    fY+= expectedLabelSize.height;
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    fY = [self createCalculation:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY];

    ////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////FOOTER//////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////
    
    if([sDocumentType isEqualToString:@"inv"])
    {
        NSString *sFooter = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowRemmittance];
        if([sFooter isEqualToString:@"Y"])
        {
            [self createFooter:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
        }
        else
        {
            [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY showFooter:NO];
        }
    }
    else
    {
        [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY showFooter:NO];
    }
    
    UIGraphicsEndPDFContext();
    
    if (self.pdfDelegate)
    {
        pdfFileName = [kDocumentsDirectory stringByAppendingPathComponent:filename];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if([fileManager fileExistsAtPath:pdfFileName])
        {
            if ([self.pdfDelegate respondsToSelector:@selector(pdfCreatedSuccessfully:)])
            {
                [self.pdfDelegate pdfCreatedSuccessfully:filename];
                NSLog(@"%d", nCurrentPage);
            }
        }
        else
        {
            if ([self.pdfDelegate respondsToSelector:@selector(pdfCreationFailed:)])
            {
                [self.pdfDelegate pdfCreationFailed:filename];
            }
        }
    }

}


- (void)createLine:(CGContextRef)currentContext startPoint:(CGPoint)startPoint endPoint:(CGPoint)endPoint
{
    CGContextSetStrokeColorWithColor(currentContext, [UIColor blackColor].CGColor);
    
   // startPoint = CGPointMake(kPDF_MARGIN, fY+22);
    //endPoint = CGPointMake(pageRect.size.width - kPDF_MARGIN, fY+22);
    
    CGContextSetStrokeColorWithColor(currentContext, [UIColor blackColor].CGColor);
    //Set the width of the pen mark
    CGContextSetLineWidth(currentContext, 0.5);
    
    // Draw a line
    //Start at this point
    CGContextMoveToPoint(currentContext, startPoint.x, startPoint.y);
    
    //Give instructions to the CGContext
    //(move "pen" around the screen)
    CGContextAddLineToPoint(currentContext, endPoint.x, endPoint.y);
    
    
    //Draw it
    CGContextStrokePath(currentContext);
}

- (void)CreateSecondPDF:(NSMutableDictionary *)documentDict
{
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    nCurrentPage = 0;
    NSLocale *theLocale = [NSLocale currentLocale];
    NSString *currencySymbol = [theLocale objectForKey:NSLocaleCurrencySymbol];
    
    CGRect pageRect = CGRectMake(0, 0, 611, 794);
    
    NSString *filename = [self getPdfFileName:documentDict];
    NSString *pdfFileName = [kDocumentsDirectory stringByAppendingPathComponent:filename];
    
    
    CGRect pdfRect = CGRectMake(0, 0, pageRect.size.width*2, pageRect.size.height*2);
    UIGraphicsBeginPDFContextToFile(pdfFileName, pdfRect, nil);
    
    UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, pageRect.size.width, pageRect.size.height), nil);
    nCurrentPage++;
    
    CGContextRef    currentContext = UIGraphicsGetCurrentContext();
    CGContextSetRGBFillColor(currentContext, 0.0, 0.0, 0.0, 1.0);
    
    CGFloat fX = kPDF_MARGIN+5;
    CGFloat fY = kPDF_MARGIN+5;
    CGFloat y;
    
    CGFloat height = [self getCompanyHeaderHeight:pageRect DocumentDict:documentDict];
    CGSize maximumLabelSize ;
    NSString *sStr = @"";
    CGSize expectedLabelSize;
    fY = [self createHeaderForTemplate2:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
    
    fY = kPDF_MARGIN+height;
    fX = (pageRect.size.width - expectedLabelSize.width)/2+100;
    maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 100), 200);    
    
    sStr = @"Bill To:";
    CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    expectedLabelSize = [sStr sizeWithFont:kBILLTOSHIPTO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sStr drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_HEADER_FONT];
    fY += expectedLabelSize.height+10;
    
    
    CGContextSelectFont (currentContext, kFONT_NAME, kBILL_CUSTOMER_NAME_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    NSString *skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO]  valueForKey:kDbInvoice_ClientName];//[self getKeyValueForID:@"contactName" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kBILL_CUSTOMER_NAME_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILL_CUSTOMER_NAME_FONT];
    
    
    CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);

    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine1];//[self getKeyValueForID:@"addressLine1" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine2];//[self getKeyValueForID:@"addressLine2" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine3];//[self getKeyValueForID:@"addressLine3" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    fY += expectedLabelSize.height;
    
    
    fY += 10;
    y = fY;
    
    NSString *sDocumentType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];
    if([sDocumentType isEqualToString:@"inv"])
    {

        sStr = @"Ship To:";
       
        
        maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 120), 200);
        CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
        
        expectedLabelSize = [sStr sizeWithFont:kBILLTOSHIPTO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [sStr drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_HEADER_FONT];
        fY += expectedLabelSize.height;
        
        CGContextSelectFont (currentContext, kFONT_NAME, kSHIP_CUSTOMER_ADDR1_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine1];//[self getKeyValueForID:@"shippingAddressLine1" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kSHIP_CUSTOMER_ADDR1_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kSHIP_CUSTOMER_ADDR1_FONT];
        fY += expectedLabelSize.height;
        
        
        CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine2];//[self getKeyValueForID:@"shippingAddressLine2" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
        fY += expectedLabelSize.height;
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine3];//[self getKeyValueForID:@"shippingAddressLine3" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
        y = fY;
        fY += expectedLabelSize.height;
    }
    
    else
    {
        y+= 30;
        fY = y;
    }
    
    maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 50), 200);
    fX = kPDF_MARGIN+5;
    
    CGContextSelectFont (currentContext, kFONT_NAME, kDOCUMENT_INFO_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    
    skey = [NSString stringWithFormat:@"Date:"];
    expectedLabelSize = [skey sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(fX, y, 100, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    
    fX+= 100;
    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_DocumentDate];//[self getKeyValueForID:@"documentDate" Disc:invoiceDict];
    
    sStr = [NSString stringWithFormat:@"%@", skey];
    expectedLabelSize = [sStr sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sStr drawInRect:CGRectMake(fX, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
        

    fX = kPDF_MARGIN+5;
    sStr = [NSString stringWithFormat:@"Invoice No:"];
    y -= expectedLabelSize.height;
    expectedLabelSize = [sStr sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sStr drawInRect:CGRectMake(fX, y, 100, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    
    fX+= 100;
    skey = [[invoiceDict valueForKey:kInvoice_INVOICEINFO]  valueForKey:kDbInvoice_DocumentNumber];//[self getKeyValueForID:@"documentNumber" Disc:invoiceDict];

    sStr = [NSString stringWithFormat:@"%@", skey];
    expectedLabelSize = [sStr sizeWithFont:kDOCUMENT_INFO_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sStr drawInRect:CGRectMake(fX, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kDOCUMENT_INFO_FONT];
    y += expectedLabelSize.height;
    
    y= fY;
    
     if([sDocumentType isEqualToString:@"inv"])
     {
         NSString *sShipping = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowShipping];
         if([sShipping isEqualToString:@"Y"])
         {
             fY += 20;
             CGRect pagesize = pageRect;
             pagesize.size = CGSizeMake((pageRect.size.width/2 + 100), pageRect.size.height);
             fX = pageRect.size.width - pagesize.size.width+kPDF_MARGIN;
             fY = [self createShippingInfo:pagesize context:currentContext DocumentDict:documentDict X:fX Y:fY showRect:NO];
         }
     }
     else
     {
         fY += 10;
     }

    CGPoint startPoint;
    CGPoint endPoint;
    
    NSMutableArray *arrItem  = nil;
    
    if([[invoiceDict allKeys] containsObject:kInvoice_ITEMSLIST])
    {
        arrItem = [invoiceDict valueForKey:kInvoice_ITEMSLIST];
    }
    CGFloat fSubTotal = 0;
    
    if([arrItem count] >0)
    {
        [self setItemTableColumnWidth:pageRect];
        
        float filler = 5.0;
        bItem = YES;
        fX = kPDF_MARGIN;
        //fY += 10;
        CGContextSetStrokeColorWithColor(currentContext, [UIColor blackColor].CGColor);
        
        startPoint = CGPointMake(kPDF_MARGIN, fY+22);
        
        fY = [self createItemHeader:pageRect context:currentContext fy:fY fx:fX showLine:YES showRect:YES];
    
        fX = kPDF_MARGIN+10;
        fY = fY+2;
        
        for(int i=0 ; i<[arrItem count] ; i++)
        {
            NSMutableDictionary *dict = [arrItem objectAtIndex:i];
            fX = kPDF_MARGIN+10;
            CGFloat fItemInfoHeight = 0;

            fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
            CGContextSelectFont (currentContext, kFONT_NAME, kITEM_INFO_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
            CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
            
            startPoint = CGPointMake(kPDF_MARGIN, startPoint.y);
            endPoint = CGPointMake(kPDF_MARGIN, fY);
            //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            
            if(bShowCode)
            {
                
                maximumLabelSize = CGSizeMake(dblCodeWidth, 100);
                skey = [dict valueForKey:kDbItem_Code];//[self getKeyValueForID:@"code" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeCharacterWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentLeft];
                
                fX+= dblCodeWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
              //  [self createLine:currentContext startPoint:startPoint endPoint:endPoint];

                fX += filler/2;
                fItemInfoHeight = expectedLabelSize.height;

            }
            
            maximumLabelSize = CGSizeMake(dblDescWidth, 100);
            skey = [dict valueForKey:kDbItem_Description];//[self getKeyValueForID:@"description" Disc:dict];
            expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
            [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
            
            fX += dblDescWidth+(filler/2);
            startPoint = CGPointMake(fX, startPoint.y);
            endPoint = CGPointMake(fX, fY);
            
           // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            
            
            fX += filler/2;
            if(expectedLabelSize.height> fItemInfoHeight)
            {
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            if(bShowQtyRate)
            {
                maximumLabelSize = CGSizeMake(dblQtyWidth, 21);
                skey = [dict valueForKey:kDbItem_Quantity];//[self getKeyValueForID:@"quantity" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT   lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblQtyWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];

                
                fX += filler/2;
                
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
                
                maximumLabelSize = CGSizeMake(dblRateWidth, 21);
                skey = [NSString stringWithFormat:@"%@ %@", currencySymbol, [dict valueForKey:kDbItem_Rate]];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblRateWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                fX += filler/2;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            if(bShowDiscount)
            {
                maximumLabelSize = CGSizeMake(dblDiscountWidth, 21);
                skey = [dict valueForKey:kDbItem_DiscountRate];//[self getKeyValueForID:@"discountrate" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblDiscountWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                
                fX += filler/2;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            if(bShowTax)
            {
                maximumLabelSize = CGSizeMake(dblTaxWidth, 21);
                skey = [dict valueForKey:kDbItem_TaxRateMulti];//[self getKeyValueForID:@"taxratemulti" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblTaxWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
               // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                
                
                fX += filler/2;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            maximumLabelSize = CGSizeMake(dblAmountWidth, 21);
            
            double rate = [[dict valueForKey:kDbItem_Rate] doubleValue];
            double quantity = [[dict valueForKey:kDbItem_Quantity] doubleValue];
            double amout = rate*quantity;
            fSubTotal += amout;
            
            skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, amout];
            
            expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
            [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
            
            fX += dblAmountWidth+filler;
            startPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, startPoint.y);
            endPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, fY);
           // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            
            if(expectedLabelSize.height> fItemInfoHeight)
            {
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            fY += fItemInfoHeight+5;

            endPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, fY);
            [self createLine:currentContext startPoint:CGPointMake(kPDF_MARGIN, fY) endPoint:endPoint];
            
            
            startPoint = CGPointMake(kPDF_MARGIN, startPoint.y);
            endPoint = CGPointMake(kPDF_MARGIN, fY);
           // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];

            fX = kPDF_MARGIN+10;
            //if(i != ([arrItem count] -1))
            {
            if(bShowCode)
            {
                fX += dblCodeWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];

                fX += filler/2;
            }
            
            fX += dblDescWidth+(filler/2);
            startPoint = CGPointMake(fX, startPoint.y);
            endPoint = CGPointMake(fX, fY);
            //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];

            fX+= filler/2;
            if(bShowQtyRate)
            {
                fX += dblQtyWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];

                
                fX += filler/2;
                
                fX += dblRateWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];

                fX += filler/2;
            }
            
            if(bShowDiscount)
            {
                fX += dblDiscountWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
              //  [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];

                fX += filler/2;
            }
            
            if(bShowTax)
            {
            
                fX += dblTaxWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];

                fX += filler/2;
            }
            
            fX += dblAmountWidth+filler;
            startPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, startPoint.y);
            endPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, fY);
            //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            [self createLine:currentContext startPoint:CGPointMake(pageRect.size.width-kPDF_MARGIN,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(pageRect.size.width-kPDF_MARGIN, fY)];
                
                [self createLine:currentContext startPoint:CGPointMake(kPDF_MARGIN,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(kPDF_MARGIN, fY)];


            
            }
            

        }
        
        CGContextSetStrokeColorWithColor(currentContext, [UIColor blackColor].CGColor);
        
        fX = kPDF_MARGIN+10;
        
        endPoint = CGPointMake(kPDF_MARGIN, fY);
        
       if(bShowCode)
        {
            fX+= dblCodeWidth+(filler/2);
            startPoint = CGPointMake(fX, startPoint.y);
            endPoint = CGPointMake(fX, fY);
        }
    }
    
    bItem = NO;
    CGContextSelectFont (currentContext, kFONT_NAME, kFOOTER_PAGE_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    
    skey = [NSString stringWithFormat:@"* Indicates non-taxable items"];
    maximumLabelSize = CGSizeMake(pageRect.size.width, 21);

    expectedLabelSize = [skey sizeWithFont:kFOOTER_PAGE_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(kPDF_MARGIN, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_PAGE_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
    
    CGContextSetLineWidth(currentContext, 1);
    
    fY+= expectedLabelSize.height+ 10;
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    
    fY = [self createCalculation:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY];

    if([sDocumentType isEqualToString:@"inv"])
    {
        NSString *sFooter = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowRemmittance];
        if([sFooter isEqualToString:@"Y"])
        {
            [self createFooter:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
        }
        else
        {
            [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY showFooter:NO];
        }
    }
    else
    {
        [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY showFooter:NO];
    }

    
    UIGraphicsEndPDFContext();
    
    if (self.pdfDelegate)
    {
        pdfFileName = [kDocumentsDirectory stringByAppendingPathComponent:filename];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if([fileManager fileExistsAtPath:pdfFileName])
        {
            if ([self.pdfDelegate respondsToSelector:@selector(pdfCreatedSuccessfully:)])
            {
                [self.pdfDelegate pdfCreatedSuccessfully:filename];
            }
        }
        else
        {
            if ([self.pdfDelegate respondsToSelector:@selector(pdfCreationFailed:)])
            {
                [self.pdfDelegate pdfCreationFailed:filename];
            }
        }
    }
}



- (void)createThirdPDF:(NSMutableDictionary *)documentDict
{
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    nCurrentPage = 0;
    
    NSLocale *theLocale = [NSLocale currentLocale];
    NSString *currencySymbol = [theLocale objectForKey:NSLocaleCurrencySymbol];
    
    CGRect pageRect = CGRectMake(0, 0, 611, 794);
    
    NSString *filename = [self getPdfFileName:documentDict];
    NSString *pdfFileName = [kDocumentsDirectory stringByAppendingPathComponent:filename];
    
    
    CGRect pdfRect = CGRectMake(0, 0, pageRect.size.width*2, pageRect.size.height*2);
    UIGraphicsBeginPDFContextToFile(pdfFileName, pdfRect, nil);
    
    UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, pageRect.size.width, pageRect.size.height), nil);
    
    nCurrentPage++;
    CGContextRef    currentContext = UIGraphicsGetCurrentContext();
    CGContextSetRGBFillColor(currentContext, 0.0, 0.0, 0.0, 1.0);
    
    CGFloat fX = kPDF_MARGIN;
    CGFloat fY = 50;
    CGFloat x;
    CGFloat y;
    
    ///*
    NSString *skey ;
    
    CGSize maximumLabelSize = CGSizeMake(pageRect.size.width/2, 200);
    NSString *sStr;
    CGSize expectedLabelSize ;
    
    fY = [self createHeaderForTemplate3:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];//:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
    
    CGFloat billHeight = [self getBillShipHeightForTemp3:pageRect DocumentDict:documentDict];
    
    CGContextSetRGBFillColor(currentContext, kHEADER_RECT_COLOR_RED1, kHEADER_RECT_COLOR_GREEN1, kHEADER_RECT_COLOR_BLUE1, 1.0);
    CGContextFillRect(currentContext, CGRectMake(5, fY+20, pageRect.size.width-10, billHeight+15));
    

    fY+= 30;
    sStr = @"Bill To:";
    
    CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    expectedLabelSize = [sStr sizeWithFont:kBILLTOSHIPTO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sStr drawInRect:CGRectMake(kPDF_MARGIN, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_HEADER_FONT];
    
    y= fY;
    x = 100;
    
    maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 120), 500);
    CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kBILL_CUSTOMER_NAME_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO]  valueForKey:kDbInvoice_ClientName];
    expectedLabelSize = [skey sizeWithFont:kBILL_CUSTOMER_NAME_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILL_CUSTOMER_NAME_FONT];
    
    
    CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine1];//[self getKeyValueForID:@"addressLine1" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine2];//[self getKeyValueForID:@"addressLine2" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine3];//[self getKeyValueForID:@"addressLine3" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    fY += expectedLabelSize.height;
    
    NSString *sDocumentType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];
    
    if([sDocumentType isEqualToString:@"inv"])
    {
        x = pageRect.size.width/2;
        
        
        sStr = @"Ship To:";
        CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
        
        expectedLabelSize = [sStr sizeWithFont:kBILLTOSHIPTO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [sStr drawInRect:CGRectMake(x, y, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_HEADER_FONT];
        
        x += 100;
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine1];//[self getKeyValueForID:@"shippingAddressLine1" Disc:invoiceDict];
        CGContextSelectFont (currentContext, kBOLD_FONT_NAME, kSHIP_CUSTOMER_ADDR1_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
        
        expectedLabelSize = [skey sizeWithFont:kSHIP_CUSTOMER_ADDR1_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, expectedLabelSize.width, expectedLabelSize.height) withFont:kSHIP_CUSTOMER_ADDR1_FONT];
        y += expectedLabelSize.height;
        
        
        CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine2];//[self getKeyValueForID:@"shippingAddressLine2" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
        y += expectedLabelSize.height;
        
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine3];//[self getKeyValueForID:@"shippingAddressLine3" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    }
    
    CGFloat fRectHeight;
    if(fY > y)
        fRectHeight = fY;
    else
        fRectHeight = y;
    
    
    fY = fRectHeight;
    
    if([sDocumentType isEqualToString:@"inv"])
    {
        NSString *sShipping = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowShipping];
        if([sShipping isEqualToString:@"Y"])
        {
            fX = kPDF_MARGIN;
            fY += 20;
            fY = [self createShippingInfo:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY showRect:NO];
        }
    }
    else
    {
        fY += 10;
    }
    
    NSMutableArray *arrItem  = nil;
    
    if([[invoiceDict allKeys] containsObject:kInvoice_ITEMSLIST])
    {
        arrItem = [invoiceDict valueForKey:kInvoice_ITEMSLIST];
    }
    CGFloat fSubTotal = 0;
    
    if([arrItem count] >0)
    {
        [self setItemTableColumnWidth:pageRect];
        
        float filler = 5.0;
        bItem = YES;
        
        [self createLine:currentContext startPoint:CGPointMake(kPDF_MARGIN, fY+10) endPoint:CGPointMake(pageRect.size.width-kPDF_MARGIN, fY+10)];


        fY = [self createItemHeader:pageRect context:currentContext fy:fY fx:fX showLine:NO showRect:NO];
        
        fX = kPDF_MARGIN+10;
        fY = fY+20;
    
        for(int i=0 ; i<[arrItem count] ; i++)
        {
            
            NSMutableDictionary *dict = [arrItem objectAtIndex:i];
            fX = kPDF_MARGIN+10;
            
            fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
            CGFloat fItemInfoHeight = 0;
            
            CGContextSelectFont (currentContext, kFONT_NAME, kITEM_INFO_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
            CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
            
            if(bShowCode)
            {
                
                maximumLabelSize = CGSizeMake(dblCodeWidth, 100);
                skey = [dict valueForKey:kDbItem_Code];//[self getKeyValueForID:@"code" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeCharacterWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentLeft];
                
                fX += dblCodeWidth+filler;
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            
            maximumLabelSize = CGSizeMake(dblDescWidth, 100);
            skey = [dict valueForKey:kDbItem_Description];//[self getKeyValueForID:@"description" Disc:dict];
            expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
            [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
            
            fX += dblDescWidth+filler;
            if(expectedLabelSize.height> fItemInfoHeight)
            {
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            if(bShowQtyRate)
            {
                maximumLabelSize = CGSizeMake(dblQtyWidth, 21);
                skey = [dict valueForKey:kDbItem_Quantity];//[self getKeyValueForID:@"quantity" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT   lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblQtyWidth+filler;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
                
                
                maximumLabelSize = CGSizeMake(dblRateWidth, 21);
                skey = [NSString stringWithFormat:@"%@ %@", currencySymbol, [dict valueForKey:kDbItem_Rate]];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblRateWidth+filler;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            if(bShowDiscount)
            {
                maximumLabelSize = CGSizeMake(dblDiscountWidth, 21);
                skey = [dict valueForKey:kDbItem_DiscountRate];//[self getKeyValueForID:@"discountrate" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblDiscountWidth+filler;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            
            }
            
            if(bShowTax)
            {
                maximumLabelSize = CGSizeMake(dblTaxWidth, 21);
                skey = [dict valueForKey:kDbItem_TaxRateMulti];//[self getKeyValueForID:@"taxratemulti" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblTaxWidth+filler;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            maximumLabelSize = CGSizeMake(dblAmountWidth, 21);
            
            double rate = [[dict valueForKey:kDbItem_Rate] doubleValue];
            double quantity = [[dict valueForKey:kDbItem_Quantity] doubleValue];
            double amout = rate*quantity;
            fSubTotal += amout;
            
            skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, amout];
            
            expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
            [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
            if(expectedLabelSize.height> fItemInfoHeight)
            {
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            fY += fItemInfoHeight+10;
        }
        
    }
    
    bItem = NO;
    
    CGContextSelectFont (currentContext, kFONT_NAME, kFOOTER_PAGE_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    
    skey = [NSString stringWithFormat:@"* Indicates non-taxable items"];
    
    expectedLabelSize = [skey sizeWithFont:kFOOTER_PAGE_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(kPDF_MARGIN, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_PAGE_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];

    CGContextSetLineWidth(currentContext, 1);
    
    fY+= expectedLabelSize.height;
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    fY = [self createCalculation:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY];

    if([sDocumentType isEqualToString:@"inv"])
    {
        NSString *sFooter = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowRemmittance];
        if([sFooter isEqualToString:@"Y"])
        {
            [self createFooter:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
        }
        else
        {
            [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY showFooter:NO];
        }
    }
    else
    {
        [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY showFooter:NO];
    }
    
    UIGraphicsEndPDFContext();
    
    if (self.pdfDelegate)
    {
        pdfFileName = [kDocumentsDirectory stringByAppendingPathComponent:filename];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if([fileManager fileExistsAtPath:pdfFileName])
        {
            if ([self.pdfDelegate respondsToSelector:@selector(pdfCreatedSuccessfully:)])
            {
                [self.pdfDelegate pdfCreatedSuccessfully:filename];
            }
        }
        else
        {
            if ([self.pdfDelegate respondsToSelector:@selector(pdfCreationFailed:)])
            {
                [self.pdfDelegate pdfCreationFailed:filename];
            }
        }
    }


}


- (void)createForthPDF:(NSMutableDictionary *)documentDict
{
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    nCurrentPage = 0;
    
    NSLocale *theLocale = [NSLocale currentLocale];
    NSString *currencySymbol = [theLocale objectForKey:NSLocaleCurrencySymbol];
    
    CGRect pageRect = CGRectMake(0, 0, 611, 794);
    
    NSString *filename = [self getPdfFileName:documentDict];
    NSString *pdfFileName = [kDocumentsDirectory stringByAppendingPathComponent:filename];
    
    
    CGRect pdfRect = CGRectMake(0, 0, pageRect.size.width*2, pageRect.size.height*2);
    UIGraphicsBeginPDFContextToFile(pdfFileName, pdfRect, nil);
    
    UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, pageRect.size.width, pageRect.size.height), nil);
    nCurrentPage++;
    
    CGContextRef    currentContext = UIGraphicsGetCurrentContext();
    CGContextSetRGBFillColor(currentContext, 0.0, 0.0, 0.0, 1.0);
    
    CGFloat fX = kPDF_MARGIN;
    CGFloat fY = kPDF_MARGIN;
    CGFloat x;
    CGFloat y;
    
    ///*
    NSString *skey ;
    
    CGSize maximumLabelSize = CGSizeMake(pageRect.size.width/2, 200);
    NSString *sStr;
    CGSize expectedLabelSize ;
    
    fY = [self createHeaderForTemplate4:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];//:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
    
    fY+= 40;
    
    sStr = @"Bill To:";
    
    CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    
    expectedLabelSize = [sStr sizeWithFont:kBILLTOSHIPTO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sStr drawInRect:CGRectMake(fX, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_HEADER_FONT];
    
    
    y= fY;
    fY+= expectedLabelSize.height;
    x = kPDF_MARGIN;
    
    //maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 120), 500);
    maximumLabelSize = CGSizeMake((pageRect.size.width- kPDF_MARGIN*2)/2- 40, 500);
    CGContextSelectFont (currentContext, kFONT_NAME, kBILL_CUSTOMER_NAME_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO]  valueForKey:kDbInvoice_ClientName];//[self getKeyValueForID:@"contactName" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kBILL_CUSTOMER_NAME_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILL_CUSTOMER_NAME_FONT];
    
    CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine1];//[self getKeyValueForID:@"addressLine1" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine2];//[self getKeyValueForID:@"addressLine2" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine3];//[self getKeyValueForID:@"addressLine3" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    fY += expectedLabelSize.height;
    
    NSString *sDocumentType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];
    
    if([sDocumentType isEqualToString:@"inv"])
    {
        x = kPDF_MARGIN+maximumLabelSize.width+ 100;
        maximumLabelSize = CGSizeMake(maximumLabelSize.width, 500);
        
        
        sStr = @"Ship To:";
        CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
        
        expectedLabelSize = [sStr sizeWithFont:kBILLTOSHIPTO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [sStr drawInRect:CGRectMake(x, y, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_HEADER_FONT];
        y+= expectedLabelSize.height;
        
        CGContextSelectFont (currentContext, kFONT_NAME, kSHIP_CUSTOMER_ADDR1_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine1];//[self getKeyValueForID:@"shippingAddressLine1" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kSHIP_CUSTOMER_ADDR1_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, expectedLabelSize.width, expectedLabelSize.height) withFont:kSHIP_CUSTOMER_ADDR1_FONT];
        y += expectedLabelSize.height;
        
        CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
        
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine2];//[self getKeyValueForID:@"shippingAddressLine2" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
        y += expectedLabelSize.height;
        
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine3];//[self getKeyValueForID:@"shippingAddressLine3" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    }
    
    CGFloat fRectHeight;
    if(fY > y)
        fRectHeight = fY;
    else
        fRectHeight = y;
    
    
    fY = fRectHeight;

    
    if([sDocumentType isEqualToString:@"inv"])
    {
        NSString *sShipping = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowShipping];
        if([sShipping isEqualToString:@"Y"])
        {
            CGContextSetStrokeColorWithColor(currentContext, [UIColor colorWithRed:(166.0/255.0) green:(45.0/255.0) blue:(63.0/255.0) alpha:1.0].CGColor);
            
            //Set the width of the pen mark
            CGContextSetLineWidth(currentContext, 1.5);
            
            // Draw a line
            //Start at this point
            CGContextMoveToPoint(currentContext, kPDF_MARGIN, fY);
            
            //Give instructions to the CGContext
            //(move "pen" around the screen)
            CGContextAddLineToPoint(currentContext, pageRect.size.width-kPDF_MARGIN , fY);
            
            
            //Draw it
            CGContextStrokePath(currentContext);
            
            
            fX = kPDF_MARGIN;
            fY += 5;
            fY = [self createShippingInfo:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY showRect:NO];
            fY+= 5;
        }
    }
    else
    {
        fY += 10;
    }
    
    
    CGContextSetStrokeColorWithColor(currentContext, [UIColor colorWithRed:(166.0/255.0) green:(45.0/255.0) blue:(63.0/255.0) alpha:1.0].CGColor);
    //Set the width of the pen mark
    CGContextSetLineWidth(currentContext, 2.5);
    // Draw a line
    //Start at this point
    CGContextMoveToPoint(currentContext, kPDF_MARGIN, fY);
    
    //Give instructions to the CGContext
    //(move "pen" around the screen)
    CGContextAddLineToPoint(currentContext, pageRect.size.width-kPDF_MARGIN , fY);
    //Draw it
    CGContextStrokePath(currentContext);
    

    CGPoint startPoint;
    CGPoint endPoint;
    
    NSMutableArray *arrItem  = nil;
    
    if([[invoiceDict allKeys] containsObject:kInvoice_ITEMSLIST])
    {
        arrItem = [invoiceDict valueForKey:kInvoice_ITEMSLIST];
    }
    CGFloat fSubTotal = 0;
    
    if([arrItem count] >0)
    {
        [self setItemTableColumnWidth:pageRect];
        
        float filler = 5.0;
        bItem = YES;
        fX = kPDF_MARGIN;
        fY +=5;
        CGContextSetStrokeColorWithColor(currentContext, [UIColor blackColor].CGColor);
        
        startPoint = CGPointMake(kPDF_MARGIN, fY+22);
        
        fY = [self createItemHeader:pageRect context:currentContext fy:fY fx:fX showLine:YES showRect:NO];
        
        fX = kPDF_MARGIN+10;
        fY = fY+2;
        
        for(int i=0 ; i<[arrItem count] ; i++)
        {
            NSMutableDictionary *dict = [arrItem objectAtIndex:i];
            fX = kPDF_MARGIN+10;
            CGFloat fItemInfoHeight = 0;
            
            fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
            CGContextSelectFont (currentContext, kFONT_NAME, kITEM_INFO_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
            CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
            
            startPoint = CGPointMake(kPDF_MARGIN, startPoint.y);
            endPoint = CGPointMake(kPDF_MARGIN, fY);
            //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            
            if(bShowCode)
            {
                
                maximumLabelSize = CGSizeMake(dblCodeWidth, 100);
                skey = [dict valueForKey:kDbItem_Code];//[self getKeyValueForID:@"code" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeCharacterWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentLeft];
                
                fX+= dblCodeWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //  [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                fX += filler/2;
                fItemInfoHeight = expectedLabelSize.height;
                
            }
            
            maximumLabelSize = CGSizeMake(dblDescWidth, 100);
            skey = [dict valueForKey:kDbItem_Description];//[self getKeyValueForID:@"description" Disc:dict];
            expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
            [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
            
            fX += dblDescWidth+(filler/2);
            startPoint = CGPointMake(fX, startPoint.y);
            endPoint = CGPointMake(fX, fY);
            
            // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            
            
            fX += filler/2;
            if(expectedLabelSize.height> fItemInfoHeight)
            {
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            if(bShowQtyRate)
            {
                maximumLabelSize = CGSizeMake(dblQtyWidth, 21);
                skey = [dict valueForKey:kDbItem_Quantity];//[self getKeyValueForID:@"quantity" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT   lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblQtyWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                
                fX += filler/2;
                
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
                
                maximumLabelSize = CGSizeMake(dblRateWidth, 21);
                skey = [NSString stringWithFormat:@"%@ %@", currencySymbol, [dict valueForKey:kDbItem_Rate]];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblRateWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                fX += filler/2;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            if(bShowDiscount)
            {
                maximumLabelSize = CGSizeMake(dblDiscountWidth, 21);
                skey = [dict valueForKey:kDbItem_DiscountRate];//[self getKeyValueForID:@"discountrate" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblDiscountWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                
                fX += filler/2;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
                
            }
            
            if(bShowTax)
            {
                maximumLabelSize = CGSizeMake(dblTaxWidth, 21);
                skey = [dict valueForKey:kDbItem_TaxRateMulti];//[self getKeyValueForID:@"taxratemulti" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblTaxWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                
                
                fX += filler/2;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            maximumLabelSize = CGSizeMake(dblAmountWidth, 21);
            
            double rate = [[dict valueForKey:kDbItem_Rate] doubleValue];
            double quantity = [[dict valueForKey:kDbItem_Quantity] doubleValue];
            double amout = rate*quantity;
            fSubTotal += amout;
            
            skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, amout];
            
            expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
            [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
            
            fX += dblAmountWidth+filler;
            startPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, startPoint.y);
            endPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, fY);
            // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            
            if(expectedLabelSize.height> fItemInfoHeight)
            {
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            fY += fItemInfoHeight+5;
            
            endPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, fY);
            [self createLine:currentContext startPoint:CGPointMake(kPDF_MARGIN, fY) endPoint:endPoint];
            
            
            startPoint = CGPointMake(kPDF_MARGIN, startPoint.y);
            endPoint = CGPointMake(kPDF_MARGIN, fY);
            // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            
            fX = kPDF_MARGIN+10;
            //if(i != ([arrItem count] -1))
            {
                if(bShowCode)
                {
                    fX += dblCodeWidth+(filler/2);
                    startPoint = CGPointMake(fX, startPoint.y);
                    endPoint = CGPointMake(fX, fY);
                    //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                    [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                    
                    fX += filler/2;
                }
                
                fX += dblDescWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                
                fX+= filler/2;
                if(bShowQtyRate)
                {
                    fX += dblQtyWidth+(filler/2);
                    startPoint = CGPointMake(fX, startPoint.y);
                    endPoint = CGPointMake(fX, fY);
                    //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                    [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                    
                    
                    fX += filler/2;
                    
                    fX += dblRateWidth+(filler/2);
                    startPoint = CGPointMake(fX, startPoint.y);
                    endPoint = CGPointMake(fX, fY);
                    //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                    [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                    
                    fX += filler/2;
                }
                
                if(bShowDiscount)
                {
                    fX += dblDiscountWidth+(filler/2);
                    startPoint = CGPointMake(fX, startPoint.y);
                    endPoint = CGPointMake(fX, fY);
                    //  [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                    [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                    
                    fX += filler/2;
                }
                
                if(bShowTax)
                {
                    
                    fX += dblTaxWidth+(filler/2);
                    startPoint = CGPointMake(fX, startPoint.y);
                    endPoint = CGPointMake(fX, fY);
                    //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                    [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                    
                    fX += filler/2;
                }
                
                fX += dblAmountWidth+filler;
                startPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, startPoint.y);
                endPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                [self createLine:currentContext startPoint:CGPointMake(pageRect.size.width-kPDF_MARGIN,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(pageRect.size.width-kPDF_MARGIN, fY)];
                
                [self createLine:currentContext startPoint:CGPointMake(kPDF_MARGIN,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(kPDF_MARGIN, fY)];
                
                
                
            }
            
            
        }
        
        CGContextSetStrokeColorWithColor(currentContext, [UIColor blackColor].CGColor);
        
        fX = kPDF_MARGIN+10;
        
        endPoint = CGPointMake(kPDF_MARGIN, fY);
        
        if(bShowCode)
        {
            fX+= dblCodeWidth+(filler/2);
            startPoint = CGPointMake(fX, startPoint.y);
            endPoint = CGPointMake(fX, fY);
        }
    }
    
    bItem = NO;
    
    CGContextSelectFont (currentContext, kFONT_NAME, kFOOTER_PAGE_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    
    skey = [NSString stringWithFormat:@"* Indicates non-taxable items"];
    
    expectedLabelSize = [skey sizeWithFont:kFOOTER_PAGE_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(kPDF_MARGIN, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_PAGE_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];

    
    fY+= expectedLabelSize.height+10;
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];



    fY = [self createCalculation:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
    
    

    if([sDocumentType isEqualToString:@"inv"])
    {
        NSString *sFooter = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowRemmittance];
        if([sFooter isEqualToString:@"Y"])
        {
            [self createFooter:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
        }
        else
        {
            [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY showFooter:NO];
        }
    }
    else
    {
        [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY showFooter:NO];
    }
    
    UIGraphicsEndPDFContext();
    
    if (self.pdfDelegate)
    {
        pdfFileName = [kDocumentsDirectory stringByAppendingPathComponent:filename];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if([fileManager fileExistsAtPath:pdfFileName])
        {
            if ([self.pdfDelegate respondsToSelector:@selector(pdfCreatedSuccessfully:)])
            {
                [self.pdfDelegate pdfCreatedSuccessfully:filename];
            }
        }
        else
        {
            if ([self.pdfDelegate respondsToSelector:@selector(pdfCreationFailed:)])
            {
                [self.pdfDelegate pdfCreationFailed:filename];
            }
        }
    }

}


- (void)createFifthPDF:(NSMutableDictionary *)documentDict
{
    AppDelegate *appdelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    nCurrentPage = 0;
    
    NSLocale *theLocale = [NSLocale currentLocale];
    NSString *currencySymbol = [theLocale objectForKey:NSLocaleCurrencySymbol];
    
    CGRect pageRect = CGRectMake(0, 0, 611, 794);
    
    NSString *filename = [self getPdfFileName:documentDict];
    NSString *pdfFileName = [kDocumentsDirectory stringByAppendingPathComponent:filename];
    
    
    CGRect pdfRect = CGRectMake(0, 0, pageRect.size.width*2, pageRect.size.height*2);
    UIGraphicsBeginPDFContextToFile(pdfFileName, pdfRect, nil);
    
    UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, pageRect.size.width, pageRect.size.height), nil);
    nCurrentPage++;
    
    CGContextRef    currentContext = UIGraphicsGetCurrentContext();
    CGContextSetRGBFillColor(currentContext, 0.0, 0.0, 0.0, 1.0);
    
    CGFloat fX = kPDF_MARGIN;
    CGFloat fY = kPDF_MARGIN;
    CGFloat x;
    CGFloat y;
    
    ///*
    NSString *skey ;
    
    CGSize maximumLabelSize = CGSizeMake(((pageRect.size.width-kPDF_MARGIN*2)/2 - 20), 200);
    NSString *sStr;
    CGSize expectedLabelSize ;
    
    fY = [self createHeaderForTemplate5:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
    
    fY+= 50;
    fX = kPDF_MARGIN;
    
    CGContextSetRGBFillColor(currentContext, kHEADER_RECT_RED_TEMP5, kHEADER_RECT_GREEN_TEMP5, kHEADER_RECT_BLUE_TEMP5, 1.0);
    CGContextFillRect(currentContext, CGRectMake(fX, fY, maximumLabelSize.width, kHEADER_RECT_HEIGHT_TEMP5));
    
    
    sStr = @"Bill To:";
    
    CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kHEADER_TEXT_RED_TEMP5, kHEADER_TEXT_GREEN_TEMP5, kHEADER_TEXT_BLUE_TEMP5, 1.0);
    
    expectedLabelSize = [sStr sizeWithFont:kBILLTOSHIPTO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [sStr drawInRect:CGRectMake(fX+2, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_HEADER_FONT];
    
    
    y= fY;
    fY+= expectedLabelSize.height+5;
    x = kPDF_MARGIN;
    
    //maximumLabelSize = CGSizeMake((pageRect.size.width/2 - 120), 500);
    ///maximumLabelSize = CGSizeMake((pageRect.size.width- kPDF_MARGIN*2)/2- 20, 500);
    CGContextSelectFont (currentContext, kFONT_NAME, kBILL_CUSTOMER_NAME_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO]  valueForKey:kDbInvoice_ClientName];//[self getKeyValueForID:@"contactName" Disc:invoiceDict];
    expectedLabelSize = [skey sizeWithFont:kBILL_CUSTOMER_NAME_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILL_CUSTOMER_NAME_FONT];
    
    CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine1];//[self getKeyValueForID:@"addressLine1" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine2];//[self getKeyValueForID:@"addressLine2" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    
    
    skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_AddressLine3];//[self getKeyValueForID:@"addressLine3" Disc:invoiceDict];
    fY += expectedLabelSize.height;
    expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(x, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    fY += expectedLabelSize.height;
    
    NSString *sDocumentType = [[invoiceDict valueForKey:kInvoice_INVOICEINFO] valueForKey:kDbInvoice_Type];
    
    if([sDocumentType isEqualToString:@"inv"])
    {
        x = pageRect.size.width-(maximumLabelSize.width+kPDF_MARGIN);
        
        CGContextSetRGBFillColor(currentContext, kHEADER_RECT_RED_TEMP5, kHEADER_RECT_GREEN_TEMP5, kHEADER_RECT_BLUE_TEMP5, 1.0);
        CGContextFillRect(currentContext, CGRectMake(x, y, maximumLabelSize.width, kHEADER_RECT_HEIGHT_TEMP5));
        

        sStr = @"Ship To:";
        CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_HEADER_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kHEADER_TEXT_RED_TEMP5, kHEADER_TEXT_GREEN_TEMP5, kHEADER_TEXT_BLUE_TEMP5, 1.0);
        
        expectedLabelSize = [sStr sizeWithFont:kBILLTOSHIPTO_HEADER_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [sStr drawInRect:CGRectMake(x+2, y, expectedLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_HEADER_FONT];
        
        y+= expectedLabelSize.height+5;
        
        
        
        CGContextSelectFont (currentContext, kFONT_NAME, kSHIP_CUSTOMER_ADDR1_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine1];//[self getKeyValueForID:@"shippingAddressLine1" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kSHIP_CUSTOMER_ADDR1_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, expectedLabelSize.width, expectedLabelSize.height) withFont:kSHIP_CUSTOMER_ADDR1_FONT];
        y += expectedLabelSize.height;
        
        CGContextSelectFont (currentContext, kFONT_NAME, kBILLTOSHIPTO_ADDR_FONT_NUMBER, kCGEncodingMacRoman);
        CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
        
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine2];//[self getKeyValueForID:@"shippingAddressLine2" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
        y += expectedLabelSize.height;
        
        
        skey = [[invoiceDict valueForKey:kInvoice_CLIENTINFO] valueForKey:kDbInvoice_ShippingAddressLine3];//[self getKeyValueForID:@"shippingAddressLine3" Disc:invoiceDict];
        expectedLabelSize = [skey sizeWithFont:kBILLTOSHIPTO_ADDR_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
        [skey drawInRect:CGRectMake(x, y, maximumLabelSize.width, expectedLabelSize.height) withFont:kBILLTOSHIPTO_ADDR_FONT];
    }
    
    CGFloat fRectHeight;
    if(fY > y)
        fRectHeight = fY;
    else
        fRectHeight = y;
    
    
    fY = fRectHeight;
    
    if([sDocumentType isEqualToString:@"inv"])
    {
        NSString *sShipping = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowShipping];
        if([sShipping isEqualToString:@"Y"])
        {
            fX = kPDF_MARGIN;
            fY += 10;
            fY = [self createShippingInfo:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY showRect:YES];
            fY+= 10;
        }
    }
    else
    {
        fY += 10;
    }

    CGPoint startPoint;
    CGPoint endPoint;
    
    NSMutableArray *arrItem  = nil;
    
    if([[invoiceDict allKeys] containsObject:kInvoice_ITEMSLIST])
    {
        arrItem = [invoiceDict valueForKey:kInvoice_ITEMSLIST];
    }
    CGFloat fSubTotal = 0;
    
    if([arrItem count] >0)
    {
        [self setItemTableColumnWidth:pageRect];
        
        float filler = 5.0;
        bItem = YES;
        fX = kPDF_MARGIN;
        fY +=5;
        CGContextSetStrokeColorWithColor(currentContext, [UIColor blackColor].CGColor);
        
        startPoint = CGPointMake(kPDF_MARGIN, fY+22);
        
        fY = [self createItemHeader:pageRect context:currentContext fy:fY fx:fX showLine:YES showRect:YES];
        
        fX = kPDF_MARGIN+10;
        fY = fY+2;
        
        for(int i=0 ; i<[arrItem count] ; i++)
        {
            NSMutableDictionary *dict = [arrItem objectAtIndex:i];
            fX = kPDF_MARGIN+10;
            CGFloat fItemInfoHeight = 0;
            
            fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
            CGContextSelectFont (currentContext, kFONT_NAME, kITEM_INFO_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
            CGContextSetRGBFillColor(currentContext, kTOTAL_TEXT_RED_COLOR, kTOTAL_TEXT_GREEN_COLOR, kTOTAL_TEXT_BLUE_COLOR, 1.0);
            
            startPoint = CGPointMake(kPDF_MARGIN, startPoint.y);
            endPoint = CGPointMake(kPDF_MARGIN, fY);
            //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            
            if(bShowCode)
            {
                
                maximumLabelSize = CGSizeMake(dblCodeWidth, 100);
                skey = [dict valueForKey:kDbItem_Code];//[self getKeyValueForID:@"code" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeCharacterWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeCharacterWrap alignment:UITextAlignmentLeft];
                
                fX+= dblCodeWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //  [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                fX += filler/2;
                fItemInfoHeight = expectedLabelSize.height;
                
            }
            
            maximumLabelSize = CGSizeMake(dblDescWidth, 100);
            skey = [dict valueForKey:kDbItem_Description];//[self getKeyValueForID:@"description" Disc:dict];
            expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
            [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentLeft];
            
            fX += dblDescWidth+(filler/2);
            startPoint = CGPointMake(fX, startPoint.y);
            endPoint = CGPointMake(fX, fY);
            
            // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            
            
            fX += filler/2;
            if(expectedLabelSize.height> fItemInfoHeight)
            {
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            if(bShowQtyRate)
            {
                maximumLabelSize = CGSizeMake(dblQtyWidth, 21);
                skey = [dict valueForKey:kDbItem_Quantity];//[self getKeyValueForID:@"quantity" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT   lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblQtyWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                
                fX += filler/2;
                
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
                
                maximumLabelSize = CGSizeMake(dblRateWidth, 21);
                skey = [NSString stringWithFormat:@"%@ %@", currencySymbol, [dict valueForKey:kDbItem_Rate]];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblRateWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                fX += filler/2;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            if(bShowDiscount)
            {
                maximumLabelSize = CGSizeMake(dblDiscountWidth, 21);
                skey = [dict valueForKey:kDbItem_DiscountRate];//[self getKeyValueForID:@"discountrate" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblDiscountWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                
                fX += filler/2;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
                
            }
            
            if(bShowTax)
            {
                maximumLabelSize = CGSizeMake(dblTaxWidth, 21);
                skey = [dict valueForKey:kDbItem_TaxRateMulti];//[self getKeyValueForID:@"taxratemulti" Disc:dict];
                expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
                [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
                
                fX += dblTaxWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                
                
                
                fX += filler/2;
                if(expectedLabelSize.height> fItemInfoHeight)
                {
                    fItemInfoHeight = expectedLabelSize.height;
                }
            }
            
            maximumLabelSize = CGSizeMake(dblAmountWidth, 21);
            
            double rate = [[dict valueForKey:kDbItem_Rate] doubleValue];
            double quantity = [[dict valueForKey:kDbItem_Quantity] doubleValue];
            double amout = rate*quantity;
            fSubTotal += amout;
            
            skey = [NSString stringWithFormat:@"%@ %.2f", currencySymbol, amout];
            
            expectedLabelSize = [skey sizeWithFont:kITEM_INFO_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
            [skey drawInRect:CGRectMake(fX, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kITEM_INFO_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];
            
            fX += dblAmountWidth+filler;
            startPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, startPoint.y);
            endPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, fY);
            // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            
            if(expectedLabelSize.height> fItemInfoHeight)
            {
                fItemInfoHeight = expectedLabelSize.height;
            }
            
            fY += fItemInfoHeight+5;
            
            endPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, fY);
            [self createLine:currentContext startPoint:CGPointMake(kPDF_MARGIN, fY) endPoint:endPoint];
            
            
            startPoint = CGPointMake(kPDF_MARGIN, startPoint.y);
            endPoint = CGPointMake(kPDF_MARGIN, fY);
            // [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
            
            fX = kPDF_MARGIN+10;
            //if(i != ([arrItem count] -1))
            {
                if(bShowCode)
                {
                    fX += dblCodeWidth+(filler/2);
                    startPoint = CGPointMake(fX, startPoint.y);
                    endPoint = CGPointMake(fX, fY);
                    //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                    [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                    
                    fX += filler/2;
                }
                
                fX += dblDescWidth+(filler/2);
                startPoint = CGPointMake(fX, startPoint.y);
                endPoint = CGPointMake(fX, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                
                fX+= filler/2;
                if(bShowQtyRate)
                {
                    fX += dblQtyWidth+(filler/2);
                    startPoint = CGPointMake(fX, startPoint.y);
                    endPoint = CGPointMake(fX, fY);
                    //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                    [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                    
                    
                    fX += filler/2;
                    
                    fX += dblRateWidth+(filler/2);
                    startPoint = CGPointMake(fX, startPoint.y);
                    endPoint = CGPointMake(fX, fY);
                    //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                    [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                    
                    fX += filler/2;
                }
                
                if(bShowDiscount)
                {
                    fX += dblDiscountWidth+(filler/2);
                    startPoint = CGPointMake(fX, startPoint.y);
                    endPoint = CGPointMake(fX, fY);
                    //  [self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                    [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                    
                    fX += filler/2;
                }
                
                if(bShowTax)
                {
                    
                    fX += dblTaxWidth+(filler/2);
                    startPoint = CGPointMake(fX, startPoint.y);
                    endPoint = CGPointMake(fX, fY);
                    //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                    [self createLine:currentContext startPoint:CGPointMake(fX,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(fX, fY)];
                    
                    fX += filler/2;
                }
                
                fX += dblAmountWidth+filler;
                startPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, startPoint.y);
                endPoint = CGPointMake(pageRect.size.width-kPDF_MARGIN, fY);
                //[self createLine:currentContext startPoint:startPoint endPoint:endPoint];
                [self createLine:currentContext startPoint:CGPointMake(pageRect.size.width-kPDF_MARGIN,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(pageRect.size.width-kPDF_MARGIN, fY)];
                
                [self createLine:currentContext startPoint:CGPointMake(kPDF_MARGIN,fY-(fItemInfoHeight+20)) endPoint:CGPointMake(kPDF_MARGIN, fY)];
                
                
                
            }
            
            
        }
        
        CGContextSetStrokeColorWithColor(currentContext, [UIColor blackColor].CGColor);
        
        fX = kPDF_MARGIN+10;
        
        endPoint = CGPointMake(kPDF_MARGIN, fY);
        
        if(bShowCode)
        {
            fX+= dblCodeWidth+(filler/2);
            startPoint = CGPointMake(fX, startPoint.y);
            endPoint = CGPointMake(fX, fY);
        }
    }
    
    bItem = NO;
    
    CGContextSelectFont (currentContext, kFONT_NAME, kFOOTER_PAGE_TEXT_FONT_NUMBER, kCGEncodingMacRoman);
    CGContextSetRGBFillColor(currentContext, kTEXT_RED_COLOR, kTEXT_GREEN_COLOR, kTEXT_BLUE_COLOR, 1.0);
    
    
    skey = [NSString stringWithFormat:@"* Indicates non-taxable items"];
    
    expectedLabelSize = [skey sizeWithFont:kFOOTER_PAGE_TEXT_FONT constrainedToSize:maximumLabelSize lineBreakMode:UILineBreakModeWordWrap];
    [skey drawInRect:CGRectMake(kPDF_MARGIN, fY, maximumLabelSize.width, expectedLabelSize.height) withFont:kFOOTER_PAGE_TEXT_FONT  lineBreakMode:UILineBreakModeWordWrap alignment:UITextAlignmentRight];

    
    fY+= expectedLabelSize.height+10;
    fY = [self getyPosition:pageRect yPosition:fY context:currentContext DocumentDict:documentDict];
    
    
    fY = [self createCalculation:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY];
    
    if([sDocumentType isEqualToString:@"inv"])
    {
        NSString *sFooter = [appdelegate.settingsDict valueForKey:kDbKeyValue_companyShowRemmittance];
        if([sFooter isEqualToString:@"Y"])
        {
            [self createFooter:pageRect context:currentContext DocumentDict:documentDict X:fX Y:fY];
        }
        else
        {
            [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY showFooter:NO];
        }
    }
    else
    {
        [self showPageNumber:pageRect context:currentContext DocumentDict:documentDict X:kPDF_MARGIN Y:fY showFooter:NO];
    }
    
    UIGraphicsEndPDFContext();
    
    if (self.pdfDelegate)
    {
        pdfFileName = [kDocumentsDirectory stringByAppendingPathComponent:filename];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if([fileManager fileExistsAtPath:pdfFileName])
        {
            if ([self.pdfDelegate respondsToSelector:@selector(pdfCreatedSuccessfully:)])
            {
                [self.pdfDelegate pdfCreatedSuccessfully:filename];
            }
        }
        else
        {
            if ([self.pdfDelegate respondsToSelector:@selector(pdfCreationFailed:)])
            {
                [self.pdfDelegate pdfCreationFailed:filename];
            }
        }
    }


}

- (void)CreatePDFFile:(NSMutableDictionary *)documentDict
{
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    NSString *sTemplateID = [appDelegate.settingsDict valueForKey:kDbKeyValue_templateID];
    if([sTemplateID isEqualToString:@"0"])
    {
        [self createFirstPDF:documentDict];
    }
    else if([sTemplateID isEqualToString:@"1"])
    {
        [self CreateSecondPDF:documentDict];
    }
    else if([sTemplateID isEqualToString:@"2"])
    {
        [self createThirdPDF:documentDict];
    }
    else if([sTemplateID isEqualToString:@"3"])
    {
        [self createForthPDF:documentDict];
    }
    else if([sTemplateID isEqualToString:@"4"])
    {
        [self createFifthPDF:documentDict];
    }
}



@end
