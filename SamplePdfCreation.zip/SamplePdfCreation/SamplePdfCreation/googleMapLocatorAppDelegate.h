//
//  googleMapLocatorAppDelegate.h
//  SamplePdfCreation
//
//  Created by VMFactor on 4/17/13.
//  Copyright (c) 2013 simpalm. All rights reserved.
//

#import <UIKit/UIKit.h>

@class googleMapLocatorViewController;

@interface googleMapLocatorAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) googleMapLocatorViewController *viewController;

@end
